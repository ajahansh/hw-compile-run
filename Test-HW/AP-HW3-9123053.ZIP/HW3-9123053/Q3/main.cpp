#include <iostream>
//#include "message.h"
//#include<utility>
//using namespace rel_ops;

template <class T> bool operator>(const T&, const char*);
template <class T> bool operator>=(const T&, const char*);
template <class T> bool operator!=(const T&, const char*);

int main()
{
	// this would work if the class has been made with < and == operators
	/*CMessage text1{"123"};
	if (text1 >= "123")
	cout << "text1 >= 123" << endl;*/
    
	return 0;
}

template <class T>
bool operator>(const T& x, const char* y)
{
	return !(x < y);
} // Requires < which is supposed to be defined in class

template <class T>
bool operator>=(const T& x, const char* y)
{
	return (!(x < y) && (x == y));
} // Requires < which is supposed to be defined in class

template <class T>
bool operator!=(const T& x, const char* y)
{
	return !(x == y);
} // Requires == which is supposed to be defined in class
