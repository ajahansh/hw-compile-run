#include <iostream>
#include <vector>
#include <fstream> // file write
#include <algorithm> // next_permutation, sort

int my_permutation(std::vector<char>&, std::ofstream&);

int main()
{
	std::ofstream out_file;
	std::vector<char> vec(4, 'a');// test vector
	vec[1] = 'c';
	vec[2] = 'a';
	vec[3] = 'd';
	out_file.open ("permutation.txt");
	std::sort (vec.begin(), vec.end()); // in order to use permutation we must sort first
	out_file << "the permutations are:" << std::endl;
	for(size_t i{}; i < vec.size(); i++) //writing the sorted string az first permutation
	{
   		out_file << vec[i];
	}
	out_file << std:: endl;
	my_permutation(vec, out_file);
	out_file.close();
	return 0;
}

int my_permutation(std::vector<char>& input_str, std::ofstream& out_file)
{
	size_t length = input_str.size();
	static std::vector<char> temp{input_str};

	// if there is more permutations the function will call itself
	if ( std::next_permutation(temp.begin(), temp.end()) )
	{
		for(size_t i{}; i < length; i++)
		{
			out_file << temp[i];
		}
		out_file << std:: endl;
		return my_permutation(temp, out_file);
	}
	else
	{
		return 0;
	}
}
