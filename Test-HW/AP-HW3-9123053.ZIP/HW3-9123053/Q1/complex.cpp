#include "complex.h"
#include <iostream>
#include <cmath>
#include <sstream>
#include <string>

CComplex::CComplex(const float rl, const float img) //constructor
{
	imag = img;
	real = rl;
	std::cout << "constructor" << std::endl; 	
}

CComplex::CComplex(const float rl) //second constructor with one argument
{
	imag = 0.0;
	real = rl;
	std::cout << "second constructor" << std::endl; 	
}

CComplex::CComplex() //default constructor
{
	this->real = 0;
	this->imag = 0;
	std::cout << "default constructor" << std::endl;
}

CComplex::CComplex(const CComplex& complex) //copy constructor
{
	imag = complex.imag;
	real = complex.real;
	std::cout << "copy constructor" << std::endl;
}

CComplex::~CComplex() //destructor
{
	std::cout << "destructor" << std::endl;
}

const char* CComplex::print() const //print function
{
	std::stringstream number;
	number << this->real << "+j" << this->imag;
	std::string temp{number.str()};
	return (temp.c_str());
}

const float CComplex::mag() const //magnitude function
{
	float magnitude{sqrtf((real*real)+(imag*imag))};
	return magnitude;
}

const float CComplex::ang() const //angle function
{
	float angle{atanf(imag / real)};
	return angle;
}

CComplex CComplex::operator+(const CComplex& complex) const // + operator
{
	CComplex temp_result;
	temp_result.imag = this->imag + complex.imag;
	temp_result.real = this->real + complex.real;
	std::cout << "operator + is called" << std::endl;
	return temp_result;
}

CComplex& CComplex::operator+=(const CComplex& complex) // += operator
{
	this->imag = this->imag + complex.imag;
	this->real = this->real + complex.real;
	std::cout << "operator += is called" << std::endl;
	return *this;
}

CComplex CComplex::operator/(const CComplex& complex) const // / operator
{
	float result_mag{this->mag() / complex.mag()};
   	float result_ang{this->ang() - complex.ang()};
	CComplex temp_result;
	temp_result.imag = result_mag*sin(result_ang);
	temp_result.real = result_mag*cos(result_ang);
	std::cout << "operator / is called" << std::endl;
	return temp_result;
}

CComplex& CComplex::operator=(const CComplex& complex) // = operator
{
	this->imag = complex.imag;
   	this->real = complex.real;
	std::cout << "operator = is called" << std::endl;
	return *this;
}
