#include <iostream>
#include "complex.h"

int main()
{
	CComplex a{2.5, 3};
	CComplex b{2};
	std::cout << "a= ";
	std::cout << a.print() << std::endl;
	CComplex c{b};
	c.imag = -3.5;
	a += b;
	c = (a + b) / (a + c);
	std::cout << "c = ";
	std::cout << c.mag() << '<' << c.ang() << std::endl;
   	return 0;
}
