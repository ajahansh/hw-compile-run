class CComplex
{
public:
	//variables
	float imag{}, real{}; //imagionary part and real part
	
    CComplex(const float, const float); //constructor
	CComplex(const float); //second constructor
	CComplex(const CComplex&); //copy constructor
	~CComplex(); //destructor
	
	//functions
	const char* print() const; //print
	const float mag() const; //magnitude
	const float ang() const; //angle

    //operator
	CComplex operator+(const CComplex&) const; // +
	CComplex& operator+=(const CComplex&); // +=
	CComplex operator/(const CComplex&) const; // /
	CComplex& operator=(const CComplex&); // =
	
private:
	CComplex(); //default constructor
};
