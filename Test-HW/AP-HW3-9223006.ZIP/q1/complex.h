#include<iostream>

//Defining class CComplex
class CComplex
{
public:

  //Constructor prototype
  CComplex (float real=0, float imag=0);

  //Copy constructor prototype
  CComplex (const CComplex& initC) ;

  //Move constructor prototype
  CComplex (CComplex&& initC) ;

  //Destructor prototype
  ~CComplex ();
  
  //Variables
  float real;
  float imag;
  
  //Functions prototype
  std::string print () const;
  float mag() const;
  float ang() const;
  

  //Operators prototype
  CComplex& operator = (const CComplex& Cright);
  CComplex& operator = (CComplex&& Cright);
  CComplex operator + (const CComplex& addend) const;
  CComplex operator - (const CComplex& subtrahend) const;
  CComplex operator * (const CComplex& multiplicand) const;
  CComplex operator / (const CComplex& divisor) const;
  CComplex& operator += (const CComplex& addend); 
  
    
};
