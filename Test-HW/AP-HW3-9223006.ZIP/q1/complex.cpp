#include"complex.h"
#include<iostream>
#include<cstring>
#include<math.h>
#include<sstream>


/***********Definition of construtors and destructors********/

//Definition of constructor
CComplex::CComplex (const float treal, const float timag)
 {
   real=treal;
   imag=timag;
 }

//Definition of copy constructor
CComplex::CComplex(const CComplex& initC) 
{
  real=initC.real;
  imag=initC.imag;
}

//Definition of move contructor
CComplex::CComplex(CComplex&& initC) 
{
  real=initC.real;
  imag=initC.imag;
}

//Definition of destructor
CComplex::~CComplex(){}

/**********Definition of functions***********/

//Definition of print
std::string CComplex::print() const
{
  std::stringstream s;
  
if (imag>=0)
    {
      s<<real<<'+'<<imag<<'j';
    }
  else
    {
      s<<real<<imag<<'j';
    }
  
 return s.str(); 
}

//Definition of mag()
float CComplex::mag() const
{
  return pow(pow(real,2)+pow(imag,2),0.5);
}

//Definition of ang()
float CComplex::ang() const
{
  return atan(imag/real)*180/3.141592;
}

/**Definition of operators**/

//Definition of '='
CComplex& CComplex::operator = (const CComplex& Cright)
{
  real = Cright.real;
  imag = Cright.imag;
  
  return *this;  
}

//Definition of move version of '='
CComplex& CComplex::operator = (CComplex&& Cright)
{
  real = Cright.real;
  imag = Cright.imag;
  
  return *this;
}

//Definition of '+'
CComplex CComplex::operator + (const CComplex& addend) const
{
  CComplex temp{real+addend.real,imag+addend.imag};
  
  return temp;
}

//Definition of '-'
CComplex CComplex::operator - (const CComplex& subtrahend) const
{
  CComplex temp{real-subtrahend.real,imag-subtrahend.imag};
  
  return temp;
}

//Definition of '*'
CComplex CComplex::operator * (const CComplex& multiplicand) const
{
  CComplex temp;
  temp.real = real * multiplicand.real - imag * multiplicand.imag;
  temp.imag = real * multiplicand.imag + imag * multiplicand.real;
  
  return temp;
}

//Definition of '/'
CComplex CComplex::operator / (const CComplex& div) const
{
  CComplex temp;
  temp.real=(real*div.real+imag*div.imag)/(pow(div.real,2)+pow(div.imag,2));
  temp.imag=(imag*div.real-real*div.imag)/(pow(div.real,2)+pow(div.imag,2));
  
  return temp;
}

//Definition of '+='
CComplex& CComplex::operator += (const CComplex& addend) 
{
  real = real + addend.real;
  imag = imag + addend.imag;
  
  return *this;  
}
