//Headers
#include"complex.h"

//Using declarations
using std::cout;
using std::endl;
using std::string;

//Start main function
int main()
{
  CComplex a{2.5f,3.0f};
  CComplex b{2.0f};
  cout<<"a= ";
  cout<<a.print()<<endl;
  CComplex c{b};
  c.imag=-3.5f;
  a+=b;
  c=(a+b)/(a+c);
  cout<<"c= ";
  cout<<c.mag()<<'<'<<c.ang()<<endl;

  return 0;
}
