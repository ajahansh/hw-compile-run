//Headers
#include<iostream>
#include<algorithm>
#include<fstream>
#include<cstring>


//Using declarations 
using std::cout;
using std::cin;
using std::endl;
using std::ofstream;
using std::next_permutation;

//prototype of permutation function
void permutation(char str[6], char* pallperms, int size);

//Start main
int main()
{
  //Defining necessary variables
  int size{};
  char str[6];
  int totalsize{1};

  //Inputting the string
  cin.getline(str,6,'\n');

  //Calculating the size of input string
  for(int i{}; i<=5; i++)
    {
      if(str[i]=='\0')
      break;
      ++size;
    }

  //Calculating the size of all permutations
  for(int i{1}; i<=size; i++)
  totalsize=totalsize*i;
  
  //Define a char string which encapsulate all the permutations
  char* ptotalstr=new char[totalsize*size];
  std::sort (str,str+size);
  
  //Permutate the string str and save the permutations in ptotalstr
  permutation(str,ptotalstr,size);

  //Opening a file named example.txt
  std::ofstream myfile;
  myfile.open ("example.txt");
  
  //Writing the permutations in the file example.txt
  for(int i{};i<=totalsize-1;i++)
    {
      for (int j{};j<=size-1;j++)
	{
	  //Null chars should not be written on the text file.  
	  if (ptotalstr[size*i])  
	  myfile<<ptotalstr[size*i+j];
	}
      myfile<<endl;
    }
  
  //closing the file example.txt
  myfile.close();
  
  return 0;
}

//Definition of permutation function
void permutation(char str[6], char* pallperms, int size)
{
  //Concatinating the distinct permutations in pallperms
  strcat(pallperms,str);

  //checking if there is another distinct permutation.if there is another one we call the function again. 
  if(next_permutation(str,str+size))
    permutation(str,pallperms,size);
 
  return;
}
