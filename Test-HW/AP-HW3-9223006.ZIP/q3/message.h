#include<iostream>
#include<cstring>

//Defining class CMessage
class CMessage
{
private:
  std::string* ptext;

public:

  void show() const
  {
    std::cout<<"Message is:"<<*ptext<<std::endl;
  }

  CMessage(const char* text = "No message")
  {
    ptext = new std::string{text};
  }

  ~CMessage()
  {
    delete ptext;
  }

  //Prototype of operators
  bool operator <(const char* str) const ;
  bool operator ==(const char* str) const ;
   
};
