//Headers
#include"message.h"

//Using declarations
using std::cout;
using std::endl;

//Template for operator '>'
template<typename T1, typename T2>
bool operator >(T1& farg, const T2& sarg) 
{
  return !((farg < sarg)|(farg == sarg));
}

//Template for operator '>='
template<typename T1, typename T2>
bool operator >=(const T1& farg, const T2& sarg) 
{
  return (farg>sarg)|(farg == sarg);
}

//Template for operator '!='
template<typename T1, typename T2>
bool operator !=(const T1& farg, const T2& sarg) 
{
  return !(farg==sarg);
}

//Start main
int main()
{
  //Define a CMessage object
  CMessage msg {"Amir"};

  //Define a const char*
  const char* str{"Ziba"};

  //Using of the operators which defined previous.
  cout<<(msg<str)<<endl;
  cout<<(msg==str)<<endl;
  cout<<(msg>str)<<endl;
  cout<<(msg>=str)<<endl;
  cout<<(msg!=str)<<endl;
  
  return 0;
}
