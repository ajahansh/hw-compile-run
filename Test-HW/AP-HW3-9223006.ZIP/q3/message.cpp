#include"message.h"

//Definition of operator '<'
bool CMessage::operator <(const char* str) const
{
  return (*ptext).length()<strlen(str);
}

//Definition of operator '=='
bool CMessage::operator ==(const char* str) const
{
  return (*ptext).length()==strlen(str);
}


