#include<iostream>
#include<fstream>
#include<string>
#include<algorithm>
#include<iomanip>
std::ofstream outfile {"permutation.txt"}; // we have to put this line out of
                                           //  permute function scope
void permute (std::string , int , int);
int main()
{
 
   std::string s;
   std::cin>> s;
   // std::sort(s.begin(), s.end());
    
    permute(s ,0, s.length()-1);
    // outfile << s << '\n';
return 0 ;
}


   void permute(std::string a, int i, int n)
{
   
   std::string temp{};
   int j;
   if (i == n)
     {
       temp = a;
        std::cout << a << std::endl;
 
	outfile << temp<< std::endl; // save the permutations in txt file
      }
    

   else
   {
       for (j = i; j <= n; j++)
       {
	 std::swap(a[i], a[j]);          
	 permute(a, i+1, n); // call the function recursively
	  std:: swap(a[i], a[j]);
       }
   }
} 
