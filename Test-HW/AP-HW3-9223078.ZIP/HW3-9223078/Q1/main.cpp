#include"complex.h"
#include<iostream>


int main()
{

 CComplex a{2.5 , 3};
 CComplex b{2};
 std::cout<<"a = " << std::endl;
 a.print();
 CComplex c{b};
 std::cout<< c.imag() <<std::endl;
 a+=b;
 c = (a+b)/(a+c);
 std::cout<< "c =" <<c.mag()<<"<" << c.ang() <<std::endl;
 
  return 0;
}
 
