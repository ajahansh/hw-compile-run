class CComplex
{
 public:
  CComplex(float real , float imag );
  CComplex(float real);
  CComplex(const CComplex& complex);
  ~CComplex();
  void print() const;
  float real() const;
  float imag() const;
  float mag() const;
  float ang() const;
  void operator +=(const CComplex& complex);
  CComplex operator +(const CComplex& complex) const;   
  void operator =(const CComplex& complex);
  CComplex operator /(const CComplex& complex);
 private:
  
  float m_real;
  float m_imag;
};
