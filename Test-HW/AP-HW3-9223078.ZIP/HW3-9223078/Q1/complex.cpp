#include"complex.h"
#include<iostream>
#include<cmath>

CComplex::CComplex (float real , float imag):
  m_real{real}, m_imag{imag}
{
  
  
}

CComplex::CComplex(float real):
  m_real{real},m_imag{0}
{
  
}
		     
CComplex::CComplex(const CComplex& complex)
{
  m_real = complex.m_real;
  m_imag = complex.m_imag;
  
}

CComplex::~CComplex()
{
 
}

void CComplex::print() const
{
  std::cout << m_real << "+"<<m_imag<<"j"<<std::endl;
  
}

float CComplex::real() const
{
  return m_real;
}

float CComplex::imag() const
{
  return m_imag;
}

float CComplex::mag() const
{
  return sqrt(pow(m_real,2)+pow(m_imag,2));
}
float CComplex::ang() const
{
  return atan(m_imag/m_real);
}

void CComplex::operator+=(const CComplex& complex) 
{
  m_real = m_real + complex.m_real;
  m_imag = m_imag + complex.m_imag;
}

CComplex CComplex::operator+(const CComplex& complex) const
{
  CComplex temp{0, 0};
  temp.m_real = m_real + complex.m_real;
  temp.m_imag = m_imag + complex.m_imag;
  return temp;
}

void CComplex::operator=(const CComplex& complex)
{
  m_real = complex.m_real;
  m_imag = complex.m_imag;
}

CComplex CComplex::operator /(const CComplex& complex)
{
  CComplex temp{0, 0};
  temp.m_real=(mag()/complex.mag()) * cos (ang()-complex.ang());
  temp.m_imag=(mag()/complex.mag()) * sin (ang()-complex.ang());
  return temp;
}

