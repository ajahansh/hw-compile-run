#include"message.h"
#include<iostream>
#include<cstring>

CMessage::CMessage (const char* text)
{
   m_len = strlen(text);
  ptext = new std::string{text};
}

CMessage::~CMessage()
{
  delete ptext;
 
}

void CMessage::show() const
{
  std::cout<< "Message is "<< *ptext<<std::endl;
}
bool CMessage::operator==(const char* text)const
{
  return m_len == strlen(text);
}

bool CMessage::operator<(const char* text) const
{
  return m_len < strlen(text);
  }
