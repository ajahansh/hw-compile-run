#include"message.h"
#include<iostream>
#include<string>

template<class T1,class T2>
         bool operator!=(const T1&  , const T2& );
template<class T1,class T2>
         bool operator>(const T1& , const T2&);
template<class T1,class T2>
         bool operator >=(const T1& , const T2&);
template<class T1,class T2>
         bool operator <=(const T1& , const T2&);
int main()
{
  CMessage msg1 {"hi"};
  if ( msg1!="HI")
    {
      std::cout<< " Bingo";
      
      }
   msg1.show();

  return 0;
}

template<class T1,class T2> bool operator!=(const T1& x , const T2& y)
{
  if (x==y)
    return false;
    else
      return true;
}

template<class T1,class T2> bool operator>(const T1& x, const T2& y)
{
  if (x<y)
    return false;
  else
    return true;
}

template<class T1,class T2> bool operator >=(const T1& x, const T2&y)
{
  if ( (x==y) || (x>y))
    return true;
  else
    return false;
}

template<class T1,class T2> bool operator <=(const T1& x, const T2&y)
{
  if ((x==y) || (x < y))
    return true;
  else
    return false;
}
