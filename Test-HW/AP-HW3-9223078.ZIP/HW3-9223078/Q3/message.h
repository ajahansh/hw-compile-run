#include<string>
class CMessage
{
 private:
  size_t m_len;
  std::string* ptext;

 public:
  CMessage ( const char* text );
  ~CMessage();
  void show() const;
  bool operator==(const char* text )const;
   bool operator<(const char* text) const;
};
