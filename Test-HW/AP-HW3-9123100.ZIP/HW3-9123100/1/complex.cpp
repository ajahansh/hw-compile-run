#include"complex.h"
#include<iostream>
#include<math.h> 
#include<stdio.h>
#include<string>
CComplex::CComplex(float r, float i): m_real{r}, m_img{i}
{   
}
CComplex::CComplex():CComplex(0,0)
{
}
CComplex::~CComplex()
{ 
}
CComplex::CComplex(const CComplex& complex)
{
  this->m_real = complex.m_real;
  this->m_img = complex.m_img;
}
std::string CComplex::print() const
{
  std::string str;
  str = std::to_string(m_real)  + '+' +
    std::to_string(m_img)+'j';
  return str;
}

void CComplex::operator +=(const CComplex& complex)
{
  this->m_real += complex.m_real;
  this->m_img +=complex.m_img;
}

CComplex CComplex::operator +(const CComplex& complex)const
{
  CComplex tmp{};
  tmp.m_real = this->m_real + complex.m_real ;
  tmp.m_img = this->m_img + complex.m_img;
  return tmp;
}

CComplex CComplex::operator / (const CComplex& complex)const
{
  CComplex tmp{};
  float mag, ang;
  mag = this->mag() / complex.mag();
  ang = this->ang() / complex.ang();
  tmp.m_real = mag * cos(ang);
  tmp.m_img = mag * sin(ang);
  return tmp;
}

float CComplex::mag()const
{
  return sqrt(m_real * m_real + m_img * m_img );
}

float CComplex::ang()const
{
  return atan(m_img / m_real);
}
