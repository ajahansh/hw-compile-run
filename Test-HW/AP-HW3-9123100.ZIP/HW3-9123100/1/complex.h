#include<string>
class CComplex
{
 public:
  CComplex(float r , float i = 0);
  CComplex(); //default constructor
  ~CComplex(); //destructor
  CComplex(const CComplex& complex);//copy constructor
  std::string print() const;
  void operator += (const CComplex& complex);
  CComplex operator + (const CComplex& complex)const;
  CComplex operator / (const CComplex& complex)const;
  float mag() const;
  float ang() const;
  float m_real, m_img;
  // not declared private in order to have access in main 
};
