#include<iostream>
#include<fstream> // write in a .txt file 
#include<algorithm> // swap
#include<cstring> // strlen(p)

void permutation(char a[], int i, int n);
int main()
{
  char p[5];//maximum length=5
  std::cin >> p ;
  permutation( p, 0, strlen(p)-1);
  return 0;
}
void permutation(char a[], int i, int n)
{
  if (i == n)
    std::cout << a << std::endl;
  else
    {
      for (int j{i}; j <= n; j++)
	{
	  std::swap(a[i], a[j]);          
	  permutation(a, i+1, n);
	  std::swap(a[i], a[j]);
	}
    }
} 
