#include<iostream>
#include<vector>
#include<cstdlib>
#include<ctime>

void PrintVec (std::vector<std::vector<std::vector<double> > >, int, int, int);

int main()
{

  std::vector<std::vector<std::vector<double> > > x;
  std::srand(std::time(0));

  for(int k = 0; k < 3; k++)
  {
    x.push_back(std::vector<std::vector<double> >() );
    for(int j = 0; j < 4; j++)
    {
      x[k].push_back(std::vector<double>() );
      for(int i = 0; i < 5; i++)
      {
        x[k][j].push_back( std::rand() );
      }
    }
  }
  PrintVec(x, 2, 3, 4);

  return 0;
}

void PrintVec (std::vector<std::vector<std::vector<double> > > y
	       , int k, int j, int i)
{
  if(i==4 && j==3){//if start of line
    std::cout << "x[" << k << "][][]:" << std::endl;
  }
  std::cout << y[k][j][i] << "\t";
  if(i == 0 && j == 0 && k == 0)//done
    return;
  else if(i == 0 && j == 0)//this 5x4 matrix is done
  {
    std::cout << std::endl << std::endl;
    i = 4;
    j = 3;
    PrintVec(y, k-1, j, i);
  }
  else if(j == 0)//this row is done
  {
    std::cout << std::endl;
    j = 3;
    PrintVec(y, k, j, i-1);
  }
  else
    PrintVec(y, k, j-1, i);

}
