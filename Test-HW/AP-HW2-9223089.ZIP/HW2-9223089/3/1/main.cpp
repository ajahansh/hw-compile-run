#include<iostream>

template<typename T1, typename T2>
auto multiply(T1 x, T2 y)->
  decltype(x[0][0]*y[0][0]);

const int N{10};

int main()
{
  int (*pInt)[N]{new int[N][N]};
  double (*pDouble)[N]{new double[N][N]};

  std::cout << "pDouble = " << std::endl;

  for(int i{}; i < N; i++)
  {
    for(int j{}; j < N; j++)
    {
      pInt[i][j] = i * N + j + 1;
      pDouble[i][j] = pInt[i][j] * 0.1;
      std::cout << pDouble[i][j] << ' ';
    }
    std::cout << std::endl;
  }

  std::cout << "Results: " << std::endl;
  std::cout << multiply(pInt, pInt) << std::endl;
  std::cout << multiply(pDouble, pDouble) << std::endl;
  std::cout << multiply(pInt, pDouble) << std::endl;

  delete [] pInt;
  delete [] pDouble;

  return 0;
}

template<typename T1, typename T2>
auto multiply(T1 x, T2 y) -> decltype(x[0][0]*y[0][0])
{
  decltype(x[0][0]*y[0][0]) z{};
  for(size_t i{}; i < N; i++)
  {
    for(size_t j{}; j < N; j++)
    {
      z += (x[i][j]*y[i][j]);
    }
  }
  return z;
}
