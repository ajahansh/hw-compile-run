#include<iostream>
#include<fstream>
#include<locale>
#include<string>

template<typename T1, typename T2>
auto multiply(T1 x, T2 y)->
  decltype(x[0][0]*y[0][0]);

const int N{10};

int main()
{
  std::ifstream file_in{"matrix.txt"};
  std::string input;
  int x;

  file_in >> input;
  file_in >> x >> x;
  int (*pInt)[N]{new int[x][N]};

  std::cout << "pInt = " << std::endl;
  for(int i{}; i < x; i++)
  {
    for(int j{}; j < x; j++)
    {
      file_in >> pInt[i][j];
      std::cout << pInt[i][j] << ' ';
    }
    std::cout << std::endl;
  }

  file_in >> input;
  file_in >> x >> x;
  double (*pDouble)[N]{new double[x][N]};

  std::cout << "pDouble = " << std::endl;
  for(int i{}; i < x; i++)
  {
    for(int j{}; j < x; j++)
    {
      file_in >> pDouble[i][j];
      std::cout << pDouble[i][j] << ' ';
    }
    std::cout << std::endl;
  }


  std::cout << "Results: " << std::endl;
  std::cout << multiply(pInt, pInt) << std::endl;
  std::cout << multiply(pDouble, pDouble) << std::endl;
  std::cout << multiply(pInt, pDouble) << std::endl;

  delete [] pInt;
  delete [] pDouble;

  return 0;
}

template<typename T1, typename T2>
auto multiply(T1 x, T2 y) -> decltype(x[0][0]*y[0][0])
{
  decltype(x[0][0]*y[0][0]) z{};
  for(size_t i{}; i < N; i++)
  {
    for(size_t j{}; j < N; j++)
    {
      z += (x[i][j]*y[i][j]);
    }
  }
  return z;
}
