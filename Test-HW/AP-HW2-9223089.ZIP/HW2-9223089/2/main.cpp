#include<iostream>
#include<string>
#include<vector>
#include<fstream>
#include<locale>

std::string shift(const std::string&, int);

int main()
{
  std::vector<std::string> input;
  std::string str;
  std::string str_shift;
  std::ifstream file_in{"statement-coded.txt"};
  std::ofstream file_out{"output.txt"};
  std::string x;
  int code_shift;

  while(file_in >> x) // input in vector
    {
      input.push_back(x);
    }

  for(size_t j = 1; j < 26; j++)
  {
    file_out << "the shift is:"  << j << std::endl;
    for(size_t i{0}; i < input.size(); i++)
    {
      str=input[i];
      str_shift = shift(str, j);
      if(str_shift == "bolbol")
	code_shift = j;
      file_out << str_shift << ' ';    
    }
    file_out << std::endl << std::endl;
  }

  std::cout << "Shift of the code: " << code_shift << std::endl;
  for(size_t i{0}; i < input.size(); i++)
  {
    str=input[i];
    str_shift = shift(str, code_shift);
    std::cout << str_shift << " "; 
  }
  std::cout << std::endl;
  return 0;
}

std::string shift(const std::string& input, int shift)
{
  int x{0};
  std::string str{input};
  for(size_t i{0}; i < input.length(); i++)
  {
    x = static_cast<int>(input[i]);

    if(isalpha(input[i]))
    {
      x += shift;
      if((islower(input[i]) && (x - 122 > 0))
	 || (isupper(input[i]) && (x - 90 > 0)))
	x = x - 26;
    }
    str[i] = static_cast<char>(x);
  }

  return(str);
}

