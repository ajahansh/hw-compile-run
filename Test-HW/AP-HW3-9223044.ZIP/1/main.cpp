#include <iostream>
#include <iomanip>
#include <string>

#include "ccomplex.h"

using std::cout;
using std::endl;

int main()
{
   CComplex a{2.5,3}; //2.5_+3j
   CComplex b{2};      //2+0j
   cout<<"a = ";
   //output real and imaginary parts
   cout << a.print() << endl;
   CComplex c{b};       //copy costructor
   c.imag=-3.5;        //c.real should be accessible too
   a += b;              //Implement +=
   c= (a + b)/(a + c);  //Implement + and /
   cout<<"c = ";
   //output magnitude and angle
   cout << c.mag() << '<' << c.ang() << endl;

}
