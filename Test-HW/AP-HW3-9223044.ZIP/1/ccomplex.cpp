#include "ccomplex.h"

#include <sstream>
#include <cmath>
#include <iostream>
#include <string>

#define _USE_MATH_DEFINES
using std::string;
using std::cout;
using std::endl;

//constructor
CComplex::CComplex(float real_part, float imag_part ):
    real{real_part},imag{imag_part}
{
    com_angle = atan(imag/real);
    com_mag = sqrt(imag*imag+real*real);
}
//constuctor
CComplex::CComplex(float real_part):CComplex (real_part , 0)
{
}

CComplex::CComplex ():CComplex (0,0)
{
}



//copy constructor
CComplex::CComplex(const CComplex &Com_obj):
    real{Com_obj.real} ,imag{Com_obj.imag}
{
    this -> com_angle = Com_obj.com_angle;
    this -> com_mag = Com_obj.com_mag;
}
CComplex CComplex::operator +=(const CComplex& complex)
{
    this -> real = this -> real + complex.real;
    this -> imag = this -> imag + complex.imag;
    this -> com_angle = atan(this->imag/this->real);
    this -> com_mag = sqrt(this->imag*this->imag+this->real*this->real);
    return *this;
}


CComplex CComplex::operator + (const CComplex& complex) const
{
    CComplex tmp{};
    tmp.real = this->real + complex.real;
    tmp.imag = this->imag + complex.imag;
    tmp.com_angle = atan(tmp.imag/tmp.real);
    tmp.com_mag = sqrt(tmp.imag*tmp.imag+tmp.real*tmp.real);
    return tmp;
}

CComplex CComplex::operator / (const CComplex& complex) const
{
    CComplex tmp{};
    tmp.com_mag = this->com_mag / complex.com_mag;
    tmp.com_angle = this -> com_angle - complex.com_angle;
    tmp.imag = tmp.com_mag * sin(tmp.com_angle);
    tmp.real = tmp.com_mag * cos(tmp.com_angle);
    return tmp;
}

CComplex CComplex::operator = (const CComplex& complex)
{
    this-> real = complex.real;
    this-> imag = complex.imag;
    this-> com_angle = complex.com_angle;
    this-> com_mag = complex.com_mag;
    return *this;
}

//return magnitude of complex number
float CComplex::mag() const
{
    return com_mag;
}
//return angle of complex number
float CComplex::ang() const
{
    return com_angle * 180 /M_PI;;
}
//show the output of complex number
string CComplex::print() const
{
    std::stringstream Complex_real{} ;
    Complex_real << this->real;
    std::stringstream Complex_imag {} ;
    Complex_imag << this->imag;
    return Complex_real.str() + " + " + Complex_imag.str() + "j";

}



