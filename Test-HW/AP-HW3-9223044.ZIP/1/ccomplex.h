#include <string>
#include <sstream>

using std::string;

class CComplex
{
public:
    CComplex(float real_part, float imag_part);
    CComplex(const CComplex& Com_obj);
    CComplex(float real_part);
    CComplex ();
    string print() const;
    CComplex operator += (const CComplex& complex);
    CComplex operator + (const CComplex& complex) const;
    CComplex operator / (const CComplex& complex) const;
    CComplex operator = (const CComplex& complex);

    float ang() const;
    float mag() const;

    float real;
    float imag;

private:
    float com_angle;
    float com_mag;


};


