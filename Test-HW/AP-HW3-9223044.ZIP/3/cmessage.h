#include <string>

class CMessage
{
private:
    std::string* ptext;
public:
    //constructor
    CMessage(const char* text);
    //function to display a message
     void show() const;
    //destructor
    ~CMessage();
    bool operator<(const char* ) const;
    bool operator==(const char*) const;
};
