#include "cmessage.h"
#include <iostream>
#include <cstring>

using std::string;

CMessage::CMessage(const char* text = "No message")
{
    ptext = new std::string {text};//alllocate space
}


void CMessage::show() const
{
    std::cout << "Message is:" <<*ptext <<std::endl;
}

bool CMessage::operator<(const char* message) const
{
   return this->ptext->size() < strlen(message);
}

bool CMessage::operator==(const char* message) const
{
return this->ptext->size() == strlen(message);
}

CMessage::~CMessage()
{
delete ptext;
}


