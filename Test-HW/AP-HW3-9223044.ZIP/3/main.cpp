#include <iostream>
#include "cmessage.h"

using std::cout;
using std::endl;

template <class T1, class T2> bool operator!=(const T1& input_1 , const T2& input_2);
template <class T1, class T2> bool operator>(const T1& input_1 , const T2& input_2);
template <class T1, class T2> bool operator>=(const T1& input_1 , const T2& input_2);
template <class T1, class T2> bool operator<=(const T1& input_1 , const T2& input_2);


int main()
{
  CMessage obj {"ghostantanie"};
  const char* text {"hello"};
  if (obj < text)
      cout << "obj < " << text << endl;
  else
      cout <<"obj > " << text << endl;
  if (obj == text)
      cout << "obj == " << text << endl;
  else if (obj >= text)
      cout << "obj >= " << text << endl;
  else
      cout << "obj <= " << text <<endl;


}


template <class T1, class T2> bool operator!=(const T1& input_1 , const T2& input_2)
{
if (!(input_1 == input_2))
    return true;
else
    return false;
}

template <class T1, class T2> bool operator>(const T1& input_1 , const T2& input_2)
{
if (input_1 < input_2)
    return false;
else
    return true;
}

template <class T1, class T2> bool operator<=(const T1& input_1 , const T2& input_2)
{
if (input_1 < input_2)
{
   if (input_1 == input_2)
        return true;
}
else
   return false;
}

template <class T1, class T2> bool operator>=(const T1& input_1 , const T2& input_2)
{
if (input_1 < input_2)
    return false;
else if (input_1 > input_2)
    return true;
else if (input_1 == input_2)
    return true;
else
    return false;

}

