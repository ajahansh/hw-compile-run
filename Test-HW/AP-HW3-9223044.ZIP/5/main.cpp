#include <iostream>
#include <algorithm>
#include <string>
#include <fstream>

using std::string;
using std::cout;
using std::endl;
using std::cin;

//permutation function
void permutation (std::string& my_string, size_t f_element, std::ofstream& my_file);
//factorial



int main()
{
    std::ofstream my_file ("output.txt");
    string my_word{};
    cout << "please enter your string number : "<<endl;
    std::getline(cin,my_word);
    permutation(my_word, 0, my_file);
}


void permutation (std::string& my_string, size_t f_element, std::ofstream& my_file)
{
   if (f_element == my_string .size()-1)
     my_file << my_string << endl;
   else
   {
       for (size_t s_element {f_element}; s_element < my_string.size(); s_element++)
       {
          std::swap(my_string[f_element], my_string[s_element]);
          permutation(my_string, f_element+1, my_file);
          std::swap(my_string[f_element], my_string[s_element]);
       }
   }
}


