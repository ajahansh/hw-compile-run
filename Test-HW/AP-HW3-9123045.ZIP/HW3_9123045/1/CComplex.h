class CComplex
{
public:
        CComplex(float p, float q);
	CComplex(float p);
	CComplex(const CComplex& c);
	const float mag();
	const float ang();
	const char* print();
	CComplex* operator+=(const CComplex& c);
	CComplex operator+(const CComplex& c);
	CComplex operator/(const CComplex& c);
	float real,imag;
};

