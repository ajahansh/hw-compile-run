#include <iostream>
#include "CComplex.h"

using std::cout;

int main()
{

	CComplex a{2.5,3};
	CComplex b{2};
	cout<<a.print();
	CComplex c{b};
	c.imag = -3.5;
	a += b;
	c = (a+b) / (a+c);
	cout<<c.mag()<<'<'<<c.ang()<<std::endl;
}
