#include <sstream>
#include <string>
#include <cmath>
#include "CComplex.h"

CComplex::CComplex(float p, float q)
{
	this->real = p;
	this->imag = q;
}

CComplex::CComplex(float p)
{
	this->real = p;
	this->imag = 0;
}

CComplex::CComplex(const CComplex& c)
{
	this->real = c.real;
	this->imag = c.imag;
}

CComplex* CComplex::operator+=(const CComplex& c)
{
	this-> real += c.real;
	this-> imag += c.imag;
	return this;
}
CComplex CComplex::operator+(const CComplex& c)
{
	CComplex temp{this-> real + c.real, this->imag + c.imag};
	return temp;
}
CComplex CComplex::operator/(const CComplex& c)
{
	float r{(this->real * c.real + this->imag * c.imag)};
	float i{(this->real * c.imag + this->imag * c.real)};
	float div = pow(pow(c.real,2) + pow(c.imag,2),0.5);
	r /= div;
	i /= div; 
	CComplex temp{r,i};
	return temp;
}

const float CComplex::ang()
{
	return atan(this->imag/this->real);
}

const float CComplex::mag()
{
	return pow(pow(this->real,2) + pow(this->imag,2),0.5);
}

const char* CComplex::print()
{
	char* out;
	std::ostringstream s;
	s << this->real << " + " << this->imag << "j\n";
	return s.str().c_str();
	//std::cout<< this->p << " + " << this->q << "j\n";
}

