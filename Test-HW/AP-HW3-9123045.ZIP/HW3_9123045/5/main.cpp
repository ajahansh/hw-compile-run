#include <iostream>
#include <cstring>

using std::cout;
void permute(char* input, int startindex);

int main()
{
	cout<<"Enter Input: ";
	char input[5];
	std::cin>>input;
	//strcpy(input, "Helo");
	permute(input, 0);
	return 0;
}

void permute(char* input,int startindex)
{
	int length = strlen(input);
	char* temp=new char[length];
	for (int i{0};i<length;i++)
		temp[i] = input[i];
	for (int i = 0; i < length; i++)
	{
		temp[startindex] = input[i];
		if (startindex == length-1)
			cout<<temp<<std::endl;
		else
			permute(temp, startindex+1);
	}
}
