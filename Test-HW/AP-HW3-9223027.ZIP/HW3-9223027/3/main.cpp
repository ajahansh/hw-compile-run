#include<iostream>
#include"message.h"

using std::cout;
using std::endl;

template<class T1, typename T2>
bool operator!=(const T1& x, const T2& y);

template<class T1, typename T2>
bool operator>(const T1& x, const T2& y);

template<class T1, typename T2>
bool operator<=(const T1& x, const T2& y);

template<class T1, typename T2>
bool operator>=(const T1& x, const T2& y);

int main()
{
  return 0;
}

template <class T1, typename T2>
bool operator!=(const T1& x, const T2& y)
{
  return !(x == y);
}

template <class T1, typename T2>
bool operator>(const T1& x, const T2& y)
{
  return (!(x == y)) && (!(x < y));
}

template <class T1, typename T2>
bool operator<=(const T1& x, const T2& y)
{
  return (x == y) || (x < y);
}

template <class T1, typename T2>
bool operator>=(const T1& x, const T2& y)
{
  return !(x < y);
}
