class CMessage
{
 private:
  std::string* ptext;
 public:
  CMessage(const char* text = "NO message");
  ~CMessage();
  bool operator<(const char* pstr) const;
  bool operator==(const char* pstr) const;
  void show();
};
