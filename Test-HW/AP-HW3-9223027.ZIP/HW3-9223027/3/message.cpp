#include<iostream>
#include<string.h>
#include"message.h"

CMessage::CMessage(const char* text)
{
  ptext = new std::string{ text };
}

CMessage::~CMessage()
{
  delete ptext;
}

bool CMessage::operator<(const char* pstr) const
{
  return this->ptext[0].size() < strlen(pstr); 
}

bool CMessage::operator==(const char* pstr) const
{
  return this->ptext[0].size() == strlen(pstr);
}

void CMessage::show()
{
  std::cout << "Message is :" << *ptext << std::endl;
}
