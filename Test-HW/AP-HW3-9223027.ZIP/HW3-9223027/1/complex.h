class CComplex
{
 public:
  CComplex(float r,float i=0);  //constructor
  CComplex(const CComplex&);  //copy constructor
  std::string print() const; //printing function
  CComplex operator=(const CComplex& Complex_n);
  //+ & / must return class types so that
  //we can do diffrent operation at once
  CComplex operator+(const CComplex& Complex_n) const;
  CComplex operator/(const CComplex& Complex_n) const;
  void operator+=(const CComplex& Complex_n);
  float mag() const;
  float ang() const;
  float real;
  float imag;
 private:
};
// const methods dont change the class datas!
