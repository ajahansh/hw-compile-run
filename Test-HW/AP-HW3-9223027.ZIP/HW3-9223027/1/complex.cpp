#include<iostream>
#include<cstring>
#include<cmath>
#include<sstream>
#include<stdio.h>
#include"complex.h"

#define pi 3.14159265

CComplex::CComplex(float r, float i)
//r->real part i->imaginary
{
  real = r;
  imag = i;
}

CComplex::CComplex(const CComplex& C_ex)
{
  real = C_ex.real;
  imag = C_ex.imag;
}

//in this function class arguments are transformed to string types
//so that they could stick toghether and function returns string
std::string CComplex::print() const
{
  std::string buffer{" + "};
  std::stringstream temp_r{""};
  std::stringstream temp_i{""};
  temp_r << real;
  temp_i << imag;
  if(imag > 0)
    buffer = temp_r.str() + buffer + temp_i.str() + "j";     
  else if(imag < 0)
    buffer = temp_r.str() + temp_i.str() + "j";
  else
    buffer = temp_r.str() + temp_i.str() + "j";
   return buffer;
}

CComplex CComplex::operator=(const CComplex& Complex_n)
{
  this->real = Complex_n.real;
  this->imag = Complex_n.imag;
  return *this;
}

CComplex CComplex::operator+(const CComplex& Complex_n) const
{
  CComplex temp{0};
  temp.real = this->real + Complex_n.real;
  temp.imag = this->imag + Complex_n.imag;
  return temp;
}

CComplex CComplex::operator/(const CComplex& Complex_n) const
{
  CComplex temp{0};
  float temp_m{};
  float temp_i{};
  temp_m = this->mag() / Complex_n.mag();
  temp_i = this->ang() - Complex_n.ang();
  temp.real = temp_m * cos (temp_i * pi/180);
  temp.imag = temp_m * sin (temp_i * pi/180);
  return temp;
}

void CComplex::operator+=(const CComplex& Complex_n)
{
  this->real = this->real + Complex_n.real;
  this->imag = this->imag + Complex_n.imag;
}

//this func caculates magnitude of complex number
float CComplex::mag() const
{
  return sqrt(real*real+imag*imag);
}

//this function caculates angle of complex number
float CComplex::ang() const
{
  return atan2 (imag, real) * 180 / pi;
}
