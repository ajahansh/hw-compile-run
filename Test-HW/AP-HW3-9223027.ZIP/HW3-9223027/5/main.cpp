#include<iostream>
#include<fstream>
#include<cstring>
#include<vector>

using std::cout;
using std::endl;

void swap(char& x1, char& x2);//this just swaps 2 arguments !
void permutation (char* word_p, int i, int len,std::ofstream& output);
//permutation func takes your word and its length and also output file
//as arguments,,it also takes variable i as argument which is going to
//used as an index of your word char .

int main()
{
  std::ofstream output{"permutation.txt"};
  char word[6]{};
  cout << "Enter Your Word(at most 5 char) :" <<endl;
  std::cin >> word;
  cout << "----------------------" << endl;
  permutation (word, 0, strlen(word), output);
  output.close();
  return 0;
}

void swap(char& x1, char& x2)
{
  char temp;
  temp=x2;
  x2=x1;
  x1=temp;
}

void permutation (char* word_p, int i, int len,std::ofstream& output)
{
  static std::vector<std::string> permute{};
  static int rep{};
  static int size{};
  if (i == len )
    {
      permute.push_back(word_p);//stores permuted words in a vector
      //this loop cheeks whether the permuted is new or old!
      for(size_t k{1}; k < permute.size(); k++)
	{
	  if(permute[permute.size()-1] == permute[k-1])
	    rep=1;//rep is set 1 if repeatation happend
	}
      //if we have new word we must write it in our file and print it
      if( (!rep) && (permute[size].size() == strlen(word_p)) )
	{
	  cout << permute[size] << " "<<endl ;
	  output << permute[size];
	  output << " \n";
	}
      size++;//index of vector(also number of produced permuted words)
      rep=0;//if rep has been set 1 we should reset it for next cheek
    }
  else
    {
      for(int j{i}; j < len; j++)//this loop products permuted words!
	{
	  swap(word_p[i], word_p[j]);
	  permutation(word_p, i+1, len, output);
	  swap(word_p[i], word_p[j]);
	  //it sets the word to initial state before producing
	  //the next permuted word
	}
    }
  
}

