#include <iostream>     // std::cout
#include <algorithm>    // std::next_permutation, std::sort
#include <cstring>
#include <fstream>

int main()
{
  //initialation variables an File streamer
  char input[6];
  size_t input_length{};
  std::ofstream file {"output.txt",std::ofstream::binary};
  //cin the string
  std::cout << "Please type your word for \
  show the permutations:\n";
  std::cin  >> input;
  input_length = strlen(input);
  std::sort (input,input+input_length);
  std::cout << "The " << input_length << "! possible \
  permutations *******:\n";
  do
    {
      std::cout << input <<std::endl; //cout the string
      file << input << std::endl; //write line the input to the file
  } while ( std::next_permutation(input,input+input_length) );
  return 0;
}