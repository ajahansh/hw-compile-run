#include "complex.h"
#include <iostream>
#include <cmath>

CComplex::CComplex(const double imag,const double real)
{
	this->imag=imag;
	this->real=real;	
}
//default constructor
CComplex::CComplex(const double real)
{
	this->imag=0;
	this->real=real;
}
void CComplex::print() const
{
	std::cout << real << "+" << imag << "j"<<std::endl;
}
void CComplex::operator+=(CComplex& b)
{
	real += b.real;
	imag += b.imag;
}
CComplex CComplex::operator+(const CComplex& b)
{
	CComplex temp{0.0,0.0};
	temp.real = real + b.real;
	temp.imag = imag + b.imag;
	return temp;
}
CComplex CComplex::operator/(const CComplex&& b)
{
	CComplex temp{0.0f,0.0f};
	double magt{},angt{};
	magt = mag()/b.mag();
	angt = ang()-b.ang();
	temp.real = magt * cos(angt*3.141592/180);	
	temp.imag = magt * sin(angt*3.141592/180);
	return temp;
}
double CComplex::mag() const
{
	return sqrt(real*real+imag*imag);	
}
double CComplex::ang() const
{
	return atan2(imag,real)*180/3.141592;
}