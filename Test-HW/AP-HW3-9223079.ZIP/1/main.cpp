#include <iostream>
#include "complex.h"

int main()
{
  //define a complex Class
  CComplex a{2.5f,3.0f};
  CComplex b{2.0f};
  std::cout << "a =";
  a.print();
  CComplex c{b}; //‫‪copy constructor‬‬
  c.imag = -3.5f; //‫‪c.real should be accessible too‬‬
  a += b; //‫=+ ‪Implement‬‬ 
  c = (a+b)/(a+c);
  std::cout << "c = ";
  std::cout << c.mag() << "<" << c.ang() << std::endl;
  return 0;
}