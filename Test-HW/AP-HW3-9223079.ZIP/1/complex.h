class CComplex {
public:
	double imag,real;
	CComplex(const double,const double);
	CComplex(const double);
	void print() const;
	void operator+=(CComplex&);
	CComplex operator+(const CComplex&);
	CComplex operator/(const CComplex&&);
	double mag()const;
	double ang()const;
private:

};