class CMessage {
public:
	CMessage(const std::string text= "No message");
	~CMessage();
	void show() const;
	bool operator==(const char*) const;	
	bool operator<(const char*) const;
private:
	std::string* ptext;
};