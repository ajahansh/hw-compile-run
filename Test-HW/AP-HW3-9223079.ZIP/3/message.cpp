#include <string>
#include <cstring>
#include "message.h"
#include <iostream>


CMessage::CMessage(const std::string text )
{	
	ptext = new std::string{text};	
}
void CMessage::show() const
{
	std::cout << "Message is:" << *ptext <<std::endl;
}
bool CMessage::operator==(const char* b) const
{
	return ptext->size() == strlen(b);
}
bool CMessage::operator<(const char* b) const
{
	return ptext->size() < strlen(b);
}
CMessage::~CMessage()
{
	delete ptext;
}