#include <iostream>
#include "message.h"
#include <string>

template <class T, class Tp> bool operator!=(const T& input_1 , const Tp& input_2);
template <class T, class Tp> bool operator>(const T& input_1 , const Tp& input_2);
template <class T, class Tp> bool operator>=(const T& input_1 , const Tp& input_2);
template <class T, class Tp> bool operator<=(const T& input_1 , const Tp& input_2);

int main()
{
  //define a complex Class
  char* b;
  std::string input1;
  char input2[50];
  std::cout << "Please type your CMesage: \n";
  std::cin  >> input1;
  std::cout << "Please type your char \
  pointer for compare: \n";  
  std::cin  >> input2;
  std::cout << "\n*************\n";
  CMessage a{input1};
  b = input2;
  if(a >= b)
  {
    a.show();
    std::cout << "Greater equal than "  << input2 
    << std::endl;
  }
  if (a != b)
  {
    a.show();
    std::cout << "Not equal than "  << input2 
    << std::endl;
  }
  return 0;
}

template <class T, class Tp> bool operator!=(const T& input_1 , const Tp& input_2)
{
if (!(input_1 == input_2))
    return true;
else
    return false;
}

template <class T, class Tp> bool operator>(const T& input_1 , const Tp& input_2)
{
if (input_1 < input_2)
    return false;
else
    return true;
}

template <class T, class Tp> bool operator<=(const T& input_1 , const Tp& input_2)
{
if (input_1 < input_2)
{
   if (input_1 == input_2)
        return true;
}
else
   return false;
}

template <class T, class Tp> bool operator>=(const T& input_1 , const Tp& input_2)
{
if (input_1 < input_2)
    return false;
else if (input_1 > input_2)
    return true;
else if (input_1 == input_2)
    return true;
else
    return false;

}
