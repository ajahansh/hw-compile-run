#include<string>
class CMessage
{
 public:
  void show(void) const;
  CMessage(const char* text);
  ~CMessage();
  std::string *ptext;
  bool operator==(const char* ch);
  bool operator<(const char* ch);
 private:
  size_t lenght; 
};
