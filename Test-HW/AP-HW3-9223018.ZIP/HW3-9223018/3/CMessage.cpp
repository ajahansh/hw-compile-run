#include"CMessage.h"
#include<iostream>
#include<string>
#include<cstring>

//display
void CMessage::show() const
{
  std::cout <<" Message is: " <<  std::endl;
}

//constructor
CMessage::CMessage(const char* text = "No Message")
  {
    lenght = strlen(text);
    ptext = new std::string{text};

  }

//deconstructor
CMessage::~CMessage()
  {
    delete ptext;
  }

// operator ==
bool CMessage::operator==(const char* ch)
{
  return  lenght == strlen(ch) ; 
}

// operator <
bool CMessage::operator<(const char* ch)
{
  return  lenght  < strlen(ch);
}
