#include<iostream>
#include"CMessage.h"

using std::cout;
using std::endl;

// templates
template <class T , class T1>
bool operator!= (T& x, const T1& y); 
template <class T , class T1>
bool operator>  (T& x, const T1& y);
template <class T ,class T1 >
bool operator<= (T& x, const T1& y); 
template <class T , class T1>
bool operator>= (T& x, const T1& y); 

// what a good:)
int main()
{ 
  return 0;
}


// !=
template <class T , class T1>
bool operator!= (T& x, const T1& y)
{
  return !(x==y);
}

// >
template <class T , class T1>
bool operator>  (T& x, const T1& y)
{
  return !((x<y) || (x == y));
}

// <=
template <class T ,class T1 >
bool operator<= (T& x, const T1& y)
{
  return (x < y) || (x == y);
}

// >=
template <class T , class T1>
bool operator>= (T& x, const T1& y)
{
  return !(x < y);
}
