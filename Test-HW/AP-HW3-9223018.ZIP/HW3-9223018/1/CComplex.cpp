#include"CComplex.h"
#include<iostream>
#include<string>
#include<sstream>
#include<cmath>
#include<math.h>

//constructor
CComplex::CComplex(float re , float im ):
  real{re} , imag{im}
  {
   
  }

//print function
const char* CComplex::print() const
{
  if (imag >= 0)
  std::cout << real  <<  " + "  << imag << " j" ;
  if (imag < 0)
  std::cout << real  <<  " - "  << fabs(imag) << " j" ; 
  return "";
}

// copy constructor
CComplex::CComplex(const CComplex &a)
{
  this->real = a.real;
  this->imag = a.imag;
}

//operator + 
CComplex CComplex::operator+(const CComplex &a) const
{
  CComplex temp{real + a.real , imag + a.imag};
  return temp;
}

//oprator =
void CComplex::operator=(const CComplex &a) 
{
  real = a.real;
  imag = a.imag;
}

operator +=
void  CComplex::operator+=(const CComplex &a) 
{
  real = real + a.real;
  imag = imag + a.imag;
}

// operator /
CComplex CComplex::operator/(const CComplex &a) const
{
  
  //real part
  float c{((real * a.real) + (imag * a.imag)) / (static_cast<float>(pow(a.real , 2) +  pow(a.imag , 2)))};

  //imaginary part
  float d{((imag * a.real) - (real * a.imag)) / (static_cast<float>(pow(a.real , 2) + pow(a.imag , 2)))};
  CComplex temp{ c , d };
  return temp;
}

// magnitude
float  CComplex::mag() const
{
  return static_cast<float>(sqrt((pow(real , 2) + pow(imag , 2)))); 
}

// angle
float  CComplex::ang() const
{
  
  if (real > 0 && imag < 0 )
    return  360 + (180 * atan(imag / real) / M_PI);
  else if (real < 0 && imag > 0 )
    return  180 + (180 * atan(imag / real) / M_PI);
  else if (real > 0 && imag > 0 )
    return  (180 * atan(imag / real) / M_PI);
  else if (real < 0 && imag < 0 )
    return  180 + (180 * atan(imag / real) / M_PI);
  else if (real == 0 && imag < 0 )
    return  -90;
  else if (real == 0 && imag > 0 )
  return  90;
  else
    return 0;

}









