class CComplex
{
 public:
  CComplex( float re , float im = 0.0 );
  const char*  print(void) const;
  CComplex(const CComplex &a);
  CComplex operator+(const CComplex &a) const;
  void operator=(const CComplex &a);
  CComplex operator/(const CComplex &a) const;
  float mag(void) const ;
  float ang(void) const ;
  void  operator+=(const CComplex &a);
  float real , imag ;
  private:
  
};
