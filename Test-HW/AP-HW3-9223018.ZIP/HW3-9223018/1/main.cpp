#include<iostream>
#include"CComplex.h"
#include<utility>

using namespace std::rel_ops;

using std::cout;
using std::endl;

int main()

{
  CComplex a(2.5,3);
  CComplex b(2);
  cout << "a = ";
  cout << a.print() << std::endl;
  CComplex c{b};
  c.imag = -3.5;
  a += b ;
  c = (a + b) / (a + c);
  cout <<  "c = ";
  cout << c.mag() << '<' << c.ang() << endl ;
  return 0;
}
