#include<iostream>
#include<cstring>
#include<string>
#include<vector>
#include<fstream>

using std::cout ;
using std::endl;
using std::cin ;

// declare functions
void change(char *a, char *b);
void permutation(char *a, int start, int ending , std::vector<std::string> &);

int main()
{
  // vector for output
  std::vector<std::string> out ;

  //input variable
  char f[6]{};
  cin >>  f ;
  int len = strlen(f);

  // recelsive funtion
  permutation(f, 0, len - 1 ,out);

  // output file
  std:: ofstream out_file {"output.txt"};
  for (int k{} ;k < static_cast<int>(out.size()) ;k++)
    {
      // save as text
      out_file <<  out[k] << endl;
    }
  return 0;    
}

// function for swap
void change(char *a, char *b)
{
  char temp;
  temp = *b;
  *b = *a;
  *a = temp;
}

// main function for permutation
void permutation(char *a, int start, int ending, std::vector<std::string> &c)
{
   if (start != ending)
     for (int i{start}; i <= ending; i++)
       {
	 //swap
	 change((a + start), (a+i));

	 //him again!! 
	 permutation(a, start + 1, ending ,c);
	 // swap 
	 change((a + start), (a + i));
       }  
   else
   {
     // at the end we recieve hrer 
     c.push_back (a);
   }
}
