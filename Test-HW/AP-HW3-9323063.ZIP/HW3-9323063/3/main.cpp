/*************************************************************
 * Mar 3 2016                                                *
 * HW3-9323063:3                                             *
 * defining template functions to define relational operators*
 *************************************************************/

#include<iostream>
#include<cstring>

/************** class ****************/

class CMessage
{
private:
    std::string* ptext; // Pointer to object text string

public:
    // Function to display a message
    void show() const
    {
	std::cout << "Message is:" << *ptext << std::endl;
    }

    // Constructor
    CMessage(const char* text = "No message")
    {
	ptext = new std::string{ text }; // Allocate space for text
    }

    // Destructor
    ~CMessage()
    {
	delete ptext;
    }
    
    // operator ==
    bool operator==(const char* msg) const
    {
	return ptext->length() == strlen(msg);
    }

    // operator <
    bool operator<(const char* msg) const
    {
	return ptext->length() <  strlen(msg);
    }


};



namespace r_ops {
    
    // defining != operator from == operator
    template<typename T1,typename T2>
    bool operator!=(const T1& x, const T2& y)
    {
	return !(x == y);
    }
    
    // defining > operator from < operator
    template<typename T1,typename T2>
    bool operator>(const T1& x, const T2& y) 
    { 
	return !(x < y) && !(x == y);
    }
    
    // defining <= operator from < operator
    template<typename T1,typename T2>
    bool operator<=(const T1& x, const T2& y) 
    { 
	return (x < y) || (x == y);
    }

    // defining >= operator from < operator
    template<typename T1,typename T2>
    bool operator>=(const T1& x, const T2& y) 
    { 
	return !(x < y); 
    }
}


using namespace r_ops; // use the defined namespace in main




/************ main **************/

int main()
{
    CMessage msg{"string"};
    
    // tests all of the operators

    if (msg == "123456")
	std::cout << "equal" << std::endl;
    
    if (msg < "new string")
	std::cout << "smaller" << std::endl;
    
    if (msg <= "new string")
	std::cout << "smaller or equal" << std::endl;

    if (msg > "str")
	std::cout << "bigger" << std::endl;

    if (msg >= "str")
	std::cout << "bigger or equal" << std::endl;

    if (msg != "new string")
	std::cout << "not equal" << std::endl;
    

    return 0;
}
