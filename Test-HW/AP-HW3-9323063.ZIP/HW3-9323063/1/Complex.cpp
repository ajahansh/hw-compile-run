#include<iostream>
#include<sstream>         // std::stringstream
#include<cstring>         // std::string
#include<cmath>           // pow() & sqrt() & atan()

#include"Complex.h"


// constructor (2 argument)
CComplex::CComplex(float real, float imag)
{
    m_real = real;
    m_imag = imag;
}

// constructor (1 argument)
CComplex::CComplex(float real)             
{
    m_real = real;
    m_imag = 0.0f;
}

// copy constructor
CComplex::CComplex(const CComplex& complex)
{
    m_real = complex.m_real;
    m_imag = complex.m_imag;
}

// += operator
CComplex& CComplex::operator+=(const CComplex& complex)
{
    m_real += complex.m_real;
    m_imag += complex.m_imag;

    return *this;
}

// + operator
CComplex CComplex::operator+(const CComplex& complex) const
{
    CComplex temp;
    temp.m_real = m_real + complex.m_real;
    temp.m_imag = m_imag + complex.m_imag;
    return temp;
}

// + r value input
CComplex CComplex::operator+(CComplex&& complex) const
{
    CComplex temp;
    temp.m_real = m_real + complex.m_real;
    temp.m_imag = m_imag + complex.m_imag;
    return temp;
}

// / operator
CComplex CComplex::operator/(const CComplex& complex) const
{
    CComplex temp;
    temp.m_real = (mag() / complex.mag()) * cos(ang() - complex.ang());
    temp.m_imag = (mag() / complex.mag()) * sin(ang() - complex.ang());
    return temp;
}

// / r value input
CComplex CComplex::operator/(CComplex&& complex) const
{
    CComplex temp;
    temp.m_real = (mag() / complex.mag()) * cos(ang() - complex.ang());
    temp.m_imag = (mag() / complex.mag()) * sin(ang() - complex.ang());
    return temp;
}

// = operator
CComplex& CComplex::operator=(const CComplex& complex)
{
    m_real = complex.m_real;
    m_imag = complex.m_imag;
    return *this;
}

// = move version
CComplex& CComplex::operator=(CComplex&& complex)
{
    m_real = complex.m_real;
    m_imag = complex.m_imag;
    return *this;
}

// magnitude function
float CComplex::mag() const
{
    return sqrt(pow(m_real, 2) + pow(m_imag, 2));
}

// angle function
float CComplex::ang() const
{
    return atan(m_imag/m_real);
}

// display complex number ( returns char*)
char* CComplex::print() const
{
    std::stringstream strs;
    strs << m_real << " + " << m_imag << 'j';
    std::string temp_str = strs.str();
    char* temp_char = (char*) temp_str.c_str();
    
    return temp_char;
}
