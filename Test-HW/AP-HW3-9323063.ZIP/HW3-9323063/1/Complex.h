class CComplex
{
public:

    CComplex(float real, float imag);      // constructor (2 arguments)
    CComplex(float real);                  // constructor (1 argument)
    CComplex() = default;                  // default constructor
    CComplex(const CComplex& complex);     // copy constructor

    CComplex& operator+=(const CComplex& complex);     // += operator
    CComplex operator+(const CComplex& complex) const; // + operator
    CComplex operator+(CComplex&& complex) const;      // + rvalue input
    CComplex operator/(const CComplex& complex) const; // / operator
    CComplex operator/(CComplex&& complex) const;      // / rvalue input
    CComplex& operator=(const CComplex& complex);      // = operator
    CComplex& operator=(CComplex&& complex);           // = move version

    float mag() const;      // magnitude function
    float ang() const;      // angle function

    char* print() const;    // display complex number

    float m_real;           // real part
    float m_imag;           // imaginary part

};
