/*************************************************************
 * Mar 3 2016                                                *
 * HW3-9323063:1                                             *
 * defining a class for complex numbers and their operations *
 *************************************************************/

#include<iostream>
#include"Complex.h"


using std::cout;
using std::endl;

int main()
{
    CComplex a{2.5f, 3.0f}; // 2.5+3j
    CComplex b{2.0f}; // 2+0j
    cout << "a = ";
    // Output real and imaginary parts
    cout << a.print() << endl; // 2.5 + 3j
    CComplex c{b}; // copy constructor
    c.m_imag = -3.5f; // c.real should be accessible too
    a += b; // Implement +=
    c = (a + b) / (a + c); // Implement + and /
    cout << "c = ";
    // Output magnitude and angle
    cout << c.mag() << '<' << c.ang() << endl;
    
    return 0;
}
