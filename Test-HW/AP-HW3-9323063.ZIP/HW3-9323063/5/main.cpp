/*************************************************************
 * Mar 3 2016                                                *
 * HW3-9323063:5                                             *
 * Defining a function to write permutations of an input     *
 * string to a file                                          *
 *************************************************************/

#include<iostream>
#include<fstream>     // ofstream  
#include<cstring>     // strlen()

void permutation(char a[], size_t i);

std::ofstream permu_file{"permutations.txt"};  // opening the file

int main()
{
    char a[0];

    std::cin >> a;
   
    permutation(a, 0);

    permu_file.close();

    return 0;
}

/********* permutation function **********/

// input a:(string) i:(loop counter) n:(string legth)

void permutation(char a[], size_t i)
{
    size_t j{};

    // output the string if all characters have been chosen
    if (i == strlen(a) - 1) 
	permu_file << a << std::endl;

    else
    {
	for (j = i; j <= strlen(a) - 1; j++)
	{
	    std::swap(a[i], a[j]);  // choose a[j] and swap with a[i]
	    permutation(a, i+1);    // swap with remaining characters
	    std::swap(a[i], a[j]);  // undo the last swap for next a[j]
	}
    }
   
} 

