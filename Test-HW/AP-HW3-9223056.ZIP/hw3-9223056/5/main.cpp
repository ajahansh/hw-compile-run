#include<iostream>
#include<cstring>
#include<fstream>
#include<vector>

void swap(char *i, char *j);
void permutation(char *str , int first , int length
		 , std::vector<std::string>&);



int main()
{
    std::vector<std::string> vector ;
    char str[7]{};       // in the question say that we need just 5 char
    std::cin >> str ;
    int n = strlen(str);
    permutation(str, 0, n-1 , vector);

    std:: ofstream out_file {"output.txt"};
    for (int x{} ; x < static_cast<int>(vector.size()) ;x++)
      {
	out_file <<  vector[x] << std::endl;
      }
  
    return 0;
    
}


/* swap Function to change values of two char */
void swap(char *i, char *j)
{
    char temp;
    temp = *i;
    *i = *j;
    *j = temp;
}

/* recursive function */
void permutation(char *str, int first, int length
		 , std::vector<std::string>& vector)
{
   int i;
   if (first == length)
     {
       std::cout << str << std::endl;
       vector.push_back(str);
     }
       
   else
   {
     i = first;
     while( i <= length)
       {
	 swap((str + first), ( str + i ));
	 permutation(str, first + 1, length , vector);
	 swap((str + first ), ( str + i ));
	 i++;
       }
   }
}



//nima sedghiye
//9223056
 
