#include<iostream>
#include<cstring>

#include"CMessage.h"

//constructor
CMessage::CMessage(const char* text)
{
  m_len = strlen(text);
  ptext = new std::string {text}; //Alocate space for text
}

//Destructor
CMessage::~CMessage()
{
  delete ptext;
}



//Function to display a massage
void CMessage::show() const
{
  std::cout << "message is:" << *ptext << std::endl;
}


bool CMessage::operator<(const char* msg) const
{
  return m_len < strlen(msg);
}

bool CMessage::operator==(const char* msg) const
{
  return m_len == strlen(msg);
}



//nima sedghiye
//9223056
