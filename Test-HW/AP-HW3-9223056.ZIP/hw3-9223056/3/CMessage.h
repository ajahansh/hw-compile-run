class CMessage
{
 private :
      std::string* ptext;                               //pointer to object text string
      size_t m_len;

      
 public :
      CMessage(const char* text = "NO message");       //constructor
      ~CMessage();                                     //destructor

      void show() const;
      bool operator<(const char* msg) const;
      bool operator==(const char* msg) const;
      
};




//nima sedghiye
//9223056
