#include<iostream>

#include"CMessage.h"

template <class T, class T1> bool operator!=(const T& x, const T1& y);    
template <class T, class T1> bool operator> (const T& x, const T1& y);     
template <class T, class T1> bool operator<=(const T& x, const T1& y);    
template <class T, class T1> bool operator>=(const T& x, const T1& y);    

int main()
{
  CMessage msg{"text"};
  const char* a = "absd";
  const char* b = "absdd";
  const char* c = "abs";

  if(msg == a)
    msg.show();

  if(msg >= a)
    if(msg > c )
      if(msg < b)
	msg.show();

  return 0;
}

template <class T, class T1> bool operator!=(const T& x, const T1& y)
{
  return !(x == y);
}

template <class T, class T1> bool operator> (const T& x, const T1& y)
{
  return !((x < y) || (x == y));
}

template <class T, class T1> bool operator<=(const T& x, const T1& y)
{
  return ((x == y) && (x < y));
}

template <class T, class T1> bool operator>=(const T& x, const T1& y)
{
  return !(x < y);
}






//nima sedghiye
//9223056
