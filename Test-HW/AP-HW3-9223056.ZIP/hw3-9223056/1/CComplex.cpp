#include<iostream>
#include<cstring>
#include <sstream>
#include<string>
#include<cmath>

#include"CComplex.h"

#define PI 3.14159265


CComplex::CComplex(float r,float i): real{r} , imag{i}
{

}

CComplex::CComplex(): CComplex(0 , 0)
{
  
}

CComplex::CComplex(const CComplex& complex)
{
	real = complex.real;
	imag = complex.imag;
}

CComplex::~CComplex()
{
  
}

CComplex::CComplex(const CComplex&& complex)
{
	real = complex.real;
	imag = complex.imag;
}

float CComplex::mag()
{
  return sqrt (real * real + imag * imag);
}

float CComplex::ang() const
{
   if(real > 0)
      return atan(imag / real) * 180 / PI;
   else if(real < 0 && imag >= 0)
     return (atan(imag / real) * 180 / PI) + 180 ;
   else if(real < 0 && imag < 0)
     return (atan(imag / real) * 180 / PI) - 180 ;
   else if(real == 0 && imag > 0)
     return 90 ;
   else if(real == 0 && imag < 0)
     return -90 ;
   else
    return 90 ;
    
}

const char* CComplex::print() const
{

  if(imag > 0 || imag == 0)
    std::cout << real << "+" << imag << "j";

  if(imag < 0)
    std::cout << real << imag << "j";  

  return "";
}


CComplex& CComplex::operator+=(const CComplex& complex)
{
        real = complex.real + real ;
	imag = complex.imag + imag;
	return *this;	
}

CComplex CComplex::operator+(const CComplex& complex) 
{
        return CComplex{complex.real + real , complex.imag + imag };
}

CComplex CComplex::operator/(const CComplex& complex) 
{
  float a = complex.real;
  float b = complex.imag;
  float c = real ;
  float d = imag;

  real = (a * c + b * d) / (a * a + b * b);
  imag = ( d * a - c * b) / (a * a + b * b);
  return *this;

 // return CComplex{((a * c + b * d)/(a * a + b * b)) , (b * c - a * d)/(a * a + b * b)};
}

CComplex& CComplex::operator=(const CComplex& Complex) 
{
	real = Complex.real;
	imag = Complex.imag;
	return *this;
}




//nima sedghiye
//9223056
