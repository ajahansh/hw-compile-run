
class CComplex
{
public:
       	float real , imag ; 
        CComplex(float r,float i = 0);           //constructor
	CComplex();                              //default constructor
	CComplex(const CComplex& complex);       //copy constructor
	CComplex(const CComplex&& complex);      //move constructor
	~CComplex();                             //destructor
	float mag();
	float ang() const;

	const char* print(void) const;
	CComplex& operator+=(const CComplex& complex);
	CComplex operator+(const CComplex& cxomplex) ;
	CComplex operator/(const CComplex& complex) ;
	CComplex& operator=(const CComplex& Complex) ;
	
private:

};

//nima sedghiye
//9223056
