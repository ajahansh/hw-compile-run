#include <iostream>
#include <fstream>

void permutation(const std::string& text, std::string remained_text, 
		 int index, std::ofstream& outFile1 );

int main ()
{
    std::string text{};
    std::string remained_text{};

    std::cout << "Enter the text" << std::endl;
    std::cin >> text ;
    
    // text.erase (0,1);
   

    std::ofstream outFile1 { "output.txt" };//a file to save proccesed data 
    outFile1 << "permutations : " << std::endl;
   
    permutation(text, remained_text, 0, outFile1);
    
    outFile1.close();
    return 0;
}

// remained text is for printing string completely
void permutation (const std::string& text, std::string remained_text,
		  int index, std::ofstream& outFile1 )
{
    if (text.size() == 1)
    {
	outFile1 << text << std::endl;
	return;
    }
    std::string temp_text{ text };
    
    for(size_t i{}; i < text.size(); i++)
    {
	if(index > 0 && i > 0) // for printing permutant of string completely
	    outFile1 << remained_text;

	outFile1 << temp_text[i]; // printing the choosen character
	
/*---------- erasing the choosen char & adding it to remained 
------------ (to be printed in next levels)
------------ passing the remained for next level permutation print*/
	temp_text.erase (i, 1); 

	remained_text.push_back(text[i]);

	permutation(temp_text, remained_text, index + 1, outFile1);
	
//---------- reseting remained text & temp_text
	remained_text.pop_back();
	temp_text = text;
    }
}
