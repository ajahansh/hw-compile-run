#include "complex.h"


int main()
{
    // 3f is not acceptable in g++ new versions
    ccomplex a{ 2.5f, static_cast<float>(3) };
    ccomplex b{ static_cast<float>(2) };
    
    a += b;
    std::cout << "a = ";
    std::cout << a.print() << std::endl;
    
    ccomplex c{b};
    c.imag = -3.5f;
    
    c = (a + b) / (a + c);
    
    std::cout << "c = ";
    std::cout << c.mag() << " < " << c.ang() << std::endl;
    
    std::cout << std::endl;
    return 0;
}
