#include <iostream>
#include <cstring>
#include <cmath>

class ccomplex
{
public:
    ccomplex(const float r = 0, const float i = 0);
    ccomplex(const ccomplex& complex2);
    
    std::string print() const;
    float mag() const;
    float ang() const;

    void operator += (const ccomplex& complex2);
    ccomplex operator + (const ccomplex&  complex2) const;
    ccomplex operator / (const ccomplex& complex2) const;
    void operator = (const ccomplex complex2);

    float real;
    float imag;
    
private:
    float m_mag;
    float m_ang;
};
