#include "complex.h"


ccomplex::ccomplex(const float r, const float i):
    real{r}, imag{i}
{
//---- calculating magnitude and angle
    this->m_mag = sqrt(pow(this->real, 2) + pow(this->real, 2));
    this->m_ang = atan(this->imag / this->real);
}

ccomplex::ccomplex(const ccomplex& complex2):
    real{complex2.real}, imag{complex2.imag}, 
    m_mag{complex2.m_mag}, m_ang{complex2.m_ang}
{
}


std::string ccomplex::print() const
{
    std::string output1{std::to_string(real)};
    std::string output2{std::to_string(imag)};
    
//----deleting useless zeros from string

    for ( size_t i{output1.size()}; i > 0; i-- )
    {

	if(output1[i - 1] == '.')
	{
	    output1[i - 1] = '\0';
	    break;
	}
	if(output1[i - 1] != '0')
	{   
	    break;
	}	
	else
	{
	    output1[i - 1] = '\0';
	}
    }    
    
    for ( size_t i{output2.size()}; i > 0 ; i-- )
    {
	
	if(output2[i - 1] == '.')
	{
	    output2[i - 1] = '\0';
	    break;
	}
	if(output2[i - 1] != '0')
	{   
	    break;
	}	
	else
	{
	    output2[i - 1] = '\0';
	}
    }    
    
    return output1 + " + " + output2 + "j";
}

float ccomplex::mag() const
{
    return this->m_mag;
}

float ccomplex::ang() const
{
    return this->m_ang;
}

void ccomplex::operator += (const ccomplex& complex2)
{
    this->real = this->real + complex2.real;
    this->imag = this->imag + complex2.imag;
    
//----calculating magnitude and angle 
    this->m_mag = sqrt(pow(this->real, 2) + pow(this->real, 2));
    this->m_ang = atan(this->imag / this->real);
}

ccomplex ccomplex::operator + (const ccomplex& complex2) const
{
    ccomplex temp{};
    
    temp.real = this->real + complex2.real;
    temp.imag = this->imag + complex2.imag;

//----calculating magnitude and angle 
    temp.m_mag = sqrt(pow(temp.real, 2) + pow(temp.real, 2));
    temp.m_ang = atan(temp.imag / temp.real);
    
    return temp;
}

ccomplex ccomplex::operator / (const ccomplex& complex2) const
{
    ccomplex temp{};
    
    temp.m_mag = this->m_mag / complex2.m_mag;
    temp.m_ang = this->m_ang - complex2.m_ang;
    temp.real = temp.m_mag * cos(temp.m_ang);
    temp.imag = temp.m_mag * sin(temp.m_ang);
    
    return temp;
}


void ccomplex::operator = (const ccomplex complex2)
{
    this->real = complex2.real;
    this->imag = complex2.imag;
    this->m_mag = complex2.m_mag;
    this->m_ang = complex2.m_ang;
}
