#include <iostream>
#include <string>
#include <fstream>

using namespace std;

void str_Permute(string, string, ofstream&);

int main() {
	string str_in;
	cin >> str_in;
	ofstream out_file{"str_permute.txt"};
    str_Permute("", str_in, out_file);
	out_file.close();
    return 0;
}

void str_Permute(string str_out, string str_in, ofstream& out_file) {
    if (str_in == "") {
        out_file << str_out << endl;
    } else {
        for(unsigned int cnt=0; cnt<str_in.length(); cnt++) {
			string shift = str_out + str_in[cnt];
		    string remain = str_in.substr(0, cnt) + str_in.substr(cnt+1);
            str_Permute(shift, remain, out_file);
    }
    }
}
