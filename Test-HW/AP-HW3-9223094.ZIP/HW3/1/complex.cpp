#include "complex.h"

CComplex::CComplex(double real, double imag) {
	this->real = real;
	this->imag = imag;
}
CComplex::CComplex(const CComplex& com_copy) {
	real = com_copy.real;
	imag = com_copy.imag;
}
CComplex CComplex::operator +=(const CComplex& com_Eadd)  {
	real = real + com_Eadd.real;
	imag = imag + com_Eadd.imag;
	return *this;
}
CComplex CComplex::operator +(const CComplex& com_add) const {
	CComplex temp;
	temp.real = real + com_add.real;
	temp.imag = imag + com_add.imag;
    return temp;
}
CComplex CComplex::operator /(const CComplex&& com_divide) const {
	double temp_mag;
	double temp_ang;
	CComplex temp;
	temp_mag = mag() / com_divide.mag();
	temp_ang = ang() - com_divide.ang();
	temp.real = temp_mag * cos(temp_ang);
	temp.imag = temp_mag * sin(temp_ang);
	return temp;
}

CComplex& CComplex::operator =(const CComplex&& com_equal) {
	real = com_equal.real;
	imag = com_equal.imag;
	return *this;
}
std::string CComplex::print() const {
	std::string str;
	std::stringstream prt;
	prt << real << " + " << imag << "j";
	str = prt.str();
	return str;
}
double CComplex::mag() const {
	return sqrt(pow(real,2) + pow(imag,2));
}
double CComplex::ang() const {
	return atan(imag / real);
}
