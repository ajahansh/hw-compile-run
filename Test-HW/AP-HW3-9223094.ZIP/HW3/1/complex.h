#include <iostream>
#include <sstream>
#include <string>
#include <cmath>

class CComplex {
public:
	CComplex(double real = 0, double imag = 0);
	CComplex(const CComplex& com_copy);
//	CComplex(CComplex&& com_move);

	CComplex operator +(const CComplex& com_add) const;
	CComplex operator +=(const CComplex& com_Eadd) ;
	CComplex operator /(const CComplex&& com_divide) const;
	CComplex& operator =(const CComplex&& com_equal);
	
	std::string print() const;

	double mag() const;
	double ang() const;
	double real;
	double imag;
}; 
