#include <string>

class CComplex
{
 public:
  double real, imag;
  
 public:
  CComplex (float re, float img); //Constructor
  CComplex (float re); //Overload , only Real nums
  CComplex (const CComplex& comp); //Copy Constructor
  CComplex (); //Default Constructor

 public: 
  CComplex& operator = (const CComplex& comp);
  CComplex operator + (const CComplex& comp);
  CComplex operator / (const CComplex& comp);
  CComplex& operator += (const CComplex& comp);
 
public:
  std::string Print() const;
  float mag() const;
  float ang() const;
};
