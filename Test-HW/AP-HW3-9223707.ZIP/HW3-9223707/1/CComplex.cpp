#include "CComplex.h"
#include <string>
#include <cmath>


//Constructs
CComplex::CComplex (float re, float img) //Constructor
{
  this->real = re;
  this->imag = img;
}
CComplex::CComplex (float re) //Overload , only Real nums
{
  this->real = re;
}
CComplex::CComplex (const CComplex& comp) //Copy Constructor
{
  this->real = comp.real;
  this->imag = comp.imag;
}
CComplex::CComplex () : CComplex (0, 0){}; //Default Constructor

//Operators
CComplex& CComplex::operator = (const CComplex& comp)
{
  this->real = comp.real;
  this->imag = comp.imag;
  return *this;
}
CComplex CComplex::operator + (const CComplex& comp)
{
  CComplex temp;
  temp.real = this->real + comp.real;
  temp.imag = this->imag + comp.imag;
  return temp;
}
CComplex CComplex::operator / (const CComplex& comp)
{
  CComplex temp;
  double deg {this->ang() - comp.ang()};
  deg = deg * 3.141592 / 180; // converting to degree
  
  temp.real =\
    (this->mag() / comp.mag()) * cos(deg);
  temp.imag =\
    (this->mag() / comp.mag()) * sin(deg);
  return temp;
}
CComplex& CComplex::operator += (const CComplex& comp)
{
  this->real += comp.real;
  this->imag += comp.imag;
  return *this;
}


//Methods
std::string CComplex::Print() const
{
  char sign;
   // to avoid e.g. 1 +- 3i , Problem with '\0' or NULL!
  sign = (imag < 0) ? ' ' : '+' ;
  std::string temp\
    {std::to_string(real) + sign + std::to_string(imag) + 'i'};
  return temp;
}
float CComplex::mag() const
{
  return sqrt( pow(this->imag, 2) + pow(this->real, 2) );
}
float CComplex::ang() const
{
  return atan2(imag, real) * 180 / 3.141592;
}
