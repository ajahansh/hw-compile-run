#include <iostream>
#include <string>
#include <cstring>
#include "CMessage.h"

CMessage::CMessage (const char* text = "No message")
{
  ptext = new std::string{ text };
}
CMessage::~CMessage ()
{
  delete ptext;
}


// compare obj with constant
bool CMessage::operator < (const char* txt) const
{
  return (*this->ptext).length() < strlen(txt);
}
bool CMessage::operator == (const char* txt) const
{
  return (*this->ptext).length() == strlen(txt);
}

// Compare objs
bool CMessage::operator < (const CMessage& msg) const
{
  return (*this->ptext).length() < (*msg.ptext).length();
}
bool CMessage::operator == (const CMessage& msg) const
{
  return (*this->ptext).length() == (*msg.ptext).length();
}

void CMessage::Show() const
{
  std::cout << "Message is :" << *ptext << std::endl;
}

