class CMessage
{
 private:
  std::string* ptext;

 public:
  void Show() const;
  CMessage (const char* text);
  ~CMessage();
 public:
  // Compare objs
  bool operator < (const CMessage& msg) const;
  bool operator == (const CMessage& msg) const;

  // compare obj with constant
  bool operator < (const char* txt) const;
  bool operator == (const char* txt) const;

};

