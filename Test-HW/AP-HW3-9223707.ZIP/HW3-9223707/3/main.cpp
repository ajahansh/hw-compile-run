#include <iostream>
#include <cmath>
#include "CMessage.h"
#include <string>

using std::cout;
using std::endl;

// Templates

template <class T1 , class T2 >
bool operator != (const T1& x, const T2& y)
{
  return !(x == y);
}
template <class T1 , class T2 >
bool operator > (const T1& x, const T2& y)
{
  return !(x < y) && !(x == y);
}
template <class T1 , class T2 >
bool operator <= (const T1& x, const T2& y)
{
  return !(x > y);
}
template <class T1 , class T2 >
bool operator >= (const T1& x, const T2& y)
{
  return !(x < y);
}


int main()
{
  
  CMessage a{"SALAM"};
  CMessage b{"SALAM1"};
  
  if (a <= "sala")
    cout << "==" << endl;
  if (b > a)
    cout << "<=" << endl;
  return 0;
}
