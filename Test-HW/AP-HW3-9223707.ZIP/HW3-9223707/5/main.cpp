#include <iostream>
#include <algorithm>
#include <fstream>
#include <string>

using std::cout;
using std::cin;
using std::endl;

void perm(std::string str);

std::ofstream out_file("output.txt");

int main()
{
  std::string str{};
  cin >> str;
  sort(str.begin(),str.end());
  perm(str);
  return 0;
}

void perm(std::string str)
{
  if(!std::next_permutation(str.begin(),str.end()))
    {
      out_file << str << endl;
      return;
    }
  out_file << str << endl;
  perm(str);
}

