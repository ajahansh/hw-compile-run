#include<iostream>
#include<cstring>
#include<fstream>

using std::cout;
using std::cin;
using std::endl;

void swap(char *, char *);          //swap function declaration
void permutation(char *, int, int); //permutation function declaration

std::ofstream out_file {"permutation.txt"};

int main()
{
   unsigned int size{};
   char* str1 = new char[size]; //allocate space for string
   cout <<"enter number of the string letters";
   cin >> size;
   while(size < 0 || size > 5)
   {
     cout <<"sorry,your digit is out of range,please try another";
     cin >> size;
    }
 
   if(size == 0)
   cout<<"the permuation of a 0 letter charechter is null!"<<endl;
 
   else
   {
     cout<<" please enter the string :"<<endl;
     cin>>str1;
   
     if(( strlen (str1))!=size)
     {
      cout<<"please enter the string with correct number of letters ";
      cin>>str1;
     }

     out_file<<"the string permutation is :"<<endl;
     permutation(str1, 0, size);
     return 0;
  
   }
}


void swap(char *x, char *y)
{
    char temp = *x;
    *x = *y;
    *y = temp;
}

//definition for permutation
//arr is the string, 
//curr is the current index to start permutation from and size is sizeof the arr

void permutation(char * arr, int curr, int size)
{
    if(curr == size-1)
    {
      for(int a{}; a<size; a++)
	  out_file << arr[a] ;
          out_file << endl;
    }

    else
    {
      for(int i{curr}; i<size; i++)
        {
            swap(&arr[curr], &arr[i]);
            permutation(arr, curr+1, size);
            swap(&arr[curr], &arr[i]);
        }
    }
}
