#include<iostream>
#include"message.h"
#include<cstring>

//prototype function templates
template <class T1, class T2>
bool operator>(const T1& x, const T2& Y);

template <class T3, class T4>
bool operator>=(const T3& x, const T4& Y);

template <class T5, class T6>
bool operator!=(const T5& x, const T6& Y);

//prototype for operator<,comparing CMessage with char type
bool operator< (const char*str,const CMessage& b );

int main()
{
  CMessage msg1 {"abbaszade"};
  const char* msg2 {"sepide"};
  msg1.show();                 //display msg1 from CMessage class
  std::cout <<"msg2 is:"<<msg2<<std::endl; //display msg2 as a const char
 
  if(operator> (msg1, msg2))
     std::cout<<"msg1 is greater than msg2"<<std::endl;
 
  if(msg1 == msg2)
     std::cout <<"msg1 equals msg2" <<std::endl;
  
  if(operator>= (msg1,msg2))
    std::cout <<"msg1 is greater than msg2 or equals msg2 " <<std::endl;
 
  if(operator!= (msg1,msg2))
    std::cout <<"msg1 is not equal to msg2" <<std::endl;
 

}

// definition of function templates work as rel_op

template <class T1,class T2>
 bool operator> (const  T1& x, const T2& y)
{
  return y<x;
 }

template <class T3,class T4>
 bool operator>= (const  T3& x, const T4& y)
{
  return y<x || x==y; 
}

template <class T4,class T5>
bool operator!= (const T4& x,const T5& y)
{
  return x!=y;
}

//definition for operator<, comparing const char with CMessage
bool operator< (const char*str,const CMessage& b)
{
  return  (strlen(str)+1)<b.m_len ;
}


 
