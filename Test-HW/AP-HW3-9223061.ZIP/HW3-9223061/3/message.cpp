#include"message.h"
#include<iostream>
#include<cstring>

void CMessage:: show() 
{
  std::cout << "Msg1 is:" << ptext << std::endl;
}

// Constructor
CMessage::CMessage(const char* text)
{ 
  m_len=strlen(text)+1;
  ptext = new char[m_len]; // Allocate space for text
  strcpy(ptext,text);
}

// Destructor
CMessage:: ~CMessage()
{
   delete ptext;
}

//define operators,comparing CMessage with const char
bool CMessage::operator< (const char*str)const
{
  return m_len < (strlen(str)+1);
}


bool CMessage::operator== (const char*str)const
{
  return m_len == (strlen(str)+1);
}


bool CMessage::operator!= (const char*str)const
{
  return m_len != (strlen(str)+1);
}
