
class CMessage
{ 
 private:
   char* ptext;
 
 public:
   unsigned int m_len;
   // Function to display a message
   void show() ;
   bool operator< (const char*str)const;
   bool operator==(const char*str)const;
   bool operator!=(const char*str)const;
   // Constructor
   CMessage(const char* text="no message");
   // Destructor
   ~CMessage();
};
