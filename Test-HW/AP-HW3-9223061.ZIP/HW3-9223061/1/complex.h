class CComplex
{ 
 private:
  
 public:
       	float image;
	float real;
	CComplex(float r,float i = 0);  //constructor
	CComplex(const CComplex& b); //copy constructor
	~CComplex();  //destructor
	CComplex& operator+=(const CComplex c);
	CComplex operator+(const CComplex c)const;
	CComplex operator/(const CComplex c);
	const char* print()const;
	float mag()const;
	float ang()const;


 };
