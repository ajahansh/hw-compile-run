#include<iostream>
#include"complex.h"
#include<cstring>

int main()
{
  CComplex a{2.5, 3}; // 2.5+3j
  CComplex b{2}; // 2+0j
 
  // Output real and imaginary parts
  std::cout << "a = ";
  std::cout<< a.print() << std::endl; // 2.5 + 3j
 
  CComplex c{b}; // copy constructor
  c.image = -3.5; // c.real should be accessible too
  a += b; // Implement +=
 
  c = (a + b)/(a + c); // Implement + and
  std::cout << "c = "<<c.real<<"+"<<c.image<<"j"<<std::endl;

  // Output magnitude and angle
  std::cout <<"c = "<< c.mag() << 
  '<' << c.ang() << std::endl;
}


