#include"complex.h"
#include<iostream>
#include<cstring>
#include<sstream>
#include<cmath>

using std::cout;
using std::string;


CComplex::CComplex(float r,float i) //constructor
{ 
  real = r;
  image = i;
}


CComplex::~CComplex() //destructor
{  
}

CComplex::CComplex(const CComplex& b) //copy constructor
{ 
   real = b.real;
   image = b.image;
}


CComplex& CComplex::operator+=(const CComplex c) //define operator +=
{
   real = real+c.real;
   image = image+c.image;
   return *this;
}

CComplex CComplex::operator+(const CComplex c)const // define operator +
{     
  return CComplex {real+c.real, image+c.image};
}

CComplex CComplex::operator/(const CComplex c) // define operator /
{ 
  return CComplex {(real*c.real+image*c.image)/(c.real*c.real+c.image*c.image),
  (image*c.real-real*c.image)/(c.real*c.real+c.image*c.image)};
}


const char* CComplex::print()const  // print function definition
{
  std::stringstream ss;
  ss << real<< "+"<< image<<"j" ;
  string str {ss.str()};
  return str.c_str();
}

float CComplex::mag()const      // magnitude function definition
{
  return sqrt (real*real+image*image);
}

float CComplex::ang()const     // angle function definition
{
  return atan (image/real);
}
