#include<iostream>
#include"CMessage.h"
#include<string>
#include<cstring>


CMessage::CMessage(const char* text = "No message")
{
  ptext = new std::string{text};
}

CMessage::~CMessage()
{
  delete ptext;
}

void CMessage::show() const
{
  std::cout<<"Message is: " << *ptext << std::endl;
}



bool CMessage::operator<(const char* txt) const
{
  return (*ptext).size() < strlen(txt);
}

bool CMessage::operator==(const char* txt) const
{
  if( (*ptext).size() == strlen(txt) )
    return true;
  else
    return false;
}



