#include<iostream>
#include<string>
#include"CMessage.h"
#include<cstring>

using std::cout;
using std::endl;


template <class T , class T2> bool operator!= (const T& message , const T2& txt);
template <class T , class T2> bool operator> (const T& message , const T2& txt);
template <class T , class T2> bool operator>= (const T& message , const T2& txt);


int main()
{
  CMessage message{"txtt"};
  message.show();
  
  const char* compare{"text"};

}


template <class T , class T2>
bool operator!= (const T& message , const T2& txt)
{
  if (message == txt )
    return false;
  else
    return true;
}

template <class T , class T2>
bool operator>= (const T& message , const T2& txt)
{
  if (message < txt )
    return false;
  else
    return true;
}


template <class T , class T2>
bool operator> (const T& message , const T2& txt)
{
  if (message < txt && message == txt )
    return false;
  else
    return true;
}
