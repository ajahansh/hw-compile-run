class CMessage
{
 private:
  std::string* ptext;   //Pointer to object text string
  
 public:

  void show() const;
  CMessage(const char* text = "No message");
  ~CMessage();
  bool operator<(const char* text) const;
  bool operator==(const char* text) const;
    
  
};

