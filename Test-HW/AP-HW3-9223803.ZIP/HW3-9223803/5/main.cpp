#include <iostream>
#include <iomanip>
#include <string>
#include <utility>
#include <fstream>

using std::cout;
using std::endl;
using std::cin;
using std::string;
using std::swap;

void permutation(string str, size_t i , std::ofstream& perms);

int main()

{
  std::ofstream out_file {"Permutations.txt"};
    string word;

    cout << "Enter a word : ";

    cin >> word;

    out_file  << "The permutations of your word are : " << endl;

    permutation(word,0,out_file);


}





void permutation(string str, size_t i,std::ofstream& perms)
{

  size_t j{},n{};
  n = str.size() - 1;


    if (i == n)
      perms << str << "\n";
    else

    {

       for (j = i; j < str.size(); j++)
        {

            swap(str[i],str[j]);

            permutation(str,i+1,perms);

            swap(str[i],str[j]);

	 }  

    }

}

 


