#include <iostream>
#include "CComplex.h"

using std::cout;
using std::endl;

int main()
{
  CComplex a{2.5 , 3};
  CComplex b{2};
  cout<<"a = ";
  cout<<a.print()<<endl;
  CComplex c{b};
  c.imag = -3.5;
  a += b;
  c = (a + b) / (a + c);
  cout<<"c = ";
  cout<<c.mag() << '<' << c.ang() << endl;
}
