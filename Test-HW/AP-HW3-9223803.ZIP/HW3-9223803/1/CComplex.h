class CComplex
{
public:
  float real , imag ;
  
  CComplex(const float a, const float b);     //normal constructor
  CComplex(const float c);                    //Single constructor
  CComplex();                                 //default constructor
  CComplex(const CComplex& cmplx);            //copy constructor
  CComplex(const CComplex&& cmplx);           //move constructor
  ~CComplex();                                //destructor
  
  const char* print(void) const;
  float mag() const;
  float ang() const;
  
  CComplex operator+(const CComplex& cmplx) const;
  CComplex operator/(const CComplex& cmplx) const;
  CComplex& operator+=(const CComplex& cmplx);
  CComplex& operator=(const CComplex& cmplx);
  
private:  
  
};
