#include<iostream>
#include"CComplex.h"
#include<sstream>
#include<string>
#include<cmath>

#define pi          3.141592653589793238462643383279502884L

using std::cout;
using std::endl;
using std::string;

CComplex::CComplex(float a , float b)  //Constructor
{
  real = a;
  imag = b;
  
}

CComplex::CComplex(float c)   //Single Constructor
{
  real = c;
  imag = 0;
  
}


CComplex::CComplex()    //Default Constructor 
{
  real = 0;
  imag = 0;
}

CComplex::CComplex(const CComplex& cmplx)   //Copy constructor
{
  real = cmplx.real;
  imag = cmplx.imag;
  
}

CComplex::~CComplex() // Destructor
{
  //cout << "Destructor" << endl;
}


const char* CComplex::print(void) const   //Print Function
{
	std::stringstream temp_ss;
  if(this->imag >= 0)
    temp_ss << this-> real << " + " << this-> imag << "j";
  else
    temp_ss << real << " - " << (-1) * imag << "j";
  
  std::string str1{ temp_ss.str() };
  return str1.c_str();
}

float CComplex::mag(void) const         //Magnitude 
{
  return sqrt( pow(this->real, 2) + pow(this->imag, 2) );
}

float CComplex::ang(void) const         //Angle 
{
  return atan(imag / real) * (180 / pi) ;
}


CComplex CComplex::operator+(const CComplex& cmplx) const
{
  return CComplex{ this->real + cmplx.real , this->imag + cmplx.imag};
}


CComplex CComplex::operator/(const CComplex& cmplx) const
{
  float denominator{},numerator_real{},numerator_imag{},temp1{},temp2{};
  denominator = pow(cmplx.real, 2) + pow(cmplx.imag, 2);
  numerator_real = (this-> real * cmplx.real) + (this->imag * cmplx.imag);
  numerator_imag = (this-> imag * cmplx.real) - (this->real * cmplx.imag);
  temp1 = numerator_real / denominator;
  temp2 = numerator_imag / denominator;
			  
  return CComplex{temp1, temp2 };
}


CComplex& CComplex::operator+=(const CComplex& cmplx)
{
  this-> real = this->real + cmplx.real;
  this-> imag = this->imag + cmplx.imag;
  
  return *this;

}

CComplex& CComplex::operator=(const CComplex& cmplx)
{
  this-> real = cmplx.real;
  this-> imag = cmplx.imag;

  return *this;
}


