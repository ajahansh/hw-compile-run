#include<iostream>
#include"complex.h"

int main()
{
  CComplex a{2.5f, 3.f};
  CComplex b{2.f};
  std::cout << "a = ";
  std::cout << a.print() << std::endl;
  CComplex c{b};
  c.imag = -3.5f;
  a += b;
  c = (a + b) / (a + c);
  std::cout << "c = ";
  std::cout << c.print() << std::endl;
  std::cout << c.mag() << " < " << c.ang() << std::endl;
}
