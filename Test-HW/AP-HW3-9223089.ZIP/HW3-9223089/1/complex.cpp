#include"complex.h"
#include<cmath>
#include<sstream>

CComplex::CComplex(float r, float i)
{
  real = r;
  imag = i;
}

CComplex::CComplex(float r)
{
  real = r;
  imag = 0;
}

CComplex::CComplex()
{
  real = 0;
  imag = 0;
}


CComplex::CComplex(CComplex& comp)
{
  real = comp.real;
  imag = comp.imag;
}

void CComplex::operator+=(const CComplex& comp)
{
  real = real + comp.real;
  imag = imag + comp.imag;
}

CComplex CComplex::operator+(const CComplex& comp) const
{
  CComplex tmp;
  tmp.real = real + comp.real;
  tmp.imag = imag + comp.imag;
  return tmp;
}

CComplex CComplex::operator/(const CComplex& comp) const
{
  CComplex tmp;
  tmp.real = ((real * comp.real) - (imag * -1 * comp.imag))/
    ((comp.real * comp.real) + (comp.imag * comp.imag));

  tmp.imag = ((real * -1 * comp.imag) + (imag * comp.real))/
    ((comp.real * comp.real) + (comp.imag * comp.imag));

  return tmp;
}

const char* CComplex::print() const
{
  std::stringstream ss;
  if(imag >= 0)
    ss << real << " + "  << imag << 'j';
  else
    ss << real << " - "  << -1 * imag << 'j';
  return ss.str().c_str();
}

float CComplex::mag() const
{
  return sqrt(real * real + imag * imag);
}

float CComplex::ang() const
{
  return atan2(imag, real);
}
