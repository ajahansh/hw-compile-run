class CComplex
{
public:
  float real, imag;
  CComplex(float r, float i); //constructor
  CComplex(float r); //constructor with 1 input element
  CComplex(); //default constructor
  CComplex(CComplex& comp); //copy constructor
  void operator+=(const CComplex& comp); //+= operator
  CComplex operator+(const CComplex& comp) const; //+ operator
  CComplex operator/(const CComplex& comp) const; // / operator
  const char* print() const; // print function
  float mag() const; // magnitude calculation
  float ang() const; // angle
};
