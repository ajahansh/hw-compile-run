#include<algorithm>
#include<string>
#include<iostream>
#include<fstream>
 
void permut(std::string s);

int main()
{
  std::string s {};
  std::cin >> s;
  std::sort(s.begin(), s.end()); //for correct use of permutation
  permut(s);

}

void permut(std::string s)
{
  static std::ofstream file_out{"output.txt"}; 
  file_out << s << std::endl;
  
  if(!(std::next_permutation(s.begin(), s.end())))
    return;
  else
    permut(s);
}
