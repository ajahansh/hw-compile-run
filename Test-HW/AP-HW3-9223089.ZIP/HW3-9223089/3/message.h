#include<string>

class CMessage
{
private:
  std::string* ptext;

public:
  void show() const;
  CMessage(const char* text = "No message"); // construnctor 
  bool operator==(const char* text) const; // == operator
  bool operator<(const char* text) const; // < operator
  ~CMessage(); // destructor
};

