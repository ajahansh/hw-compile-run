#include<iostream>
#include<cstring>
#include"message.h"

namespace operators //defining a namespace that does what real_op did.
{
  template<typename T1, typename T2>
  bool operator!=(const T1& x, const T2& y)
  {
    return !(x == y);
  }

  template<typename T1, typename T2>
  bool operator>(const T1& x, const T2& y) 
  {
    return !(x == y) && !(x < y); 
  }
  
  template<typename T1, typename T2>
  bool operator<=(const T1& x, const T2& y) 
  {
    return (x == y) || (x < y); 
  }

  template<typename T1, typename T2>
  bool operator>= (const T1& x, const T2& y) 
  {
    return !(x < y);
  }
}

using namespace operators;

int main()
{
  CMessage s{"Sara Ghaemi"};
  const char* f{"name"};

  s.show();
  std::cout << "The char* is: " << f  << std::endl;

  if(s == f)
    std::cout << "Message and char* are equal" << std::endl;

  if(s != f)
    std::cout << "Message and char* are not equal" << std::endl;

  if(s <= f)
    std::cout << "Message is less than char* or equal to it" 
	      << std::endl;

  if(s >= f)
    std::cout << "Message is more than char* or equal to it" 
	      << std::endl;
  if(s > f)
    std::cout << "Message is more than char*" << std::endl;

  if(s < f)
    std::cout << "Message is less than char*" << std::endl;



}



