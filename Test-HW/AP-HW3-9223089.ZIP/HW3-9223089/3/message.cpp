#include"message.h"
#include<iostream>
#include<cstring>

void CMessage::show() const
{
  std::cout << "Message is:" << *ptext << std::endl;
}

CMessage::CMessage(const char* text)
{
  ptext = new std::string{text};
}

bool CMessage::operator==(const char* text) const
{
  return (*ptext).length() == strlen(text);
}

bool CMessage::operator<(const char* text) const
{
  return (*ptext).length() < strlen(text);
}

CMessage::~CMessage()
{
  delete ptext;
}

