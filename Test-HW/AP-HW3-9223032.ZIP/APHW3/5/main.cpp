#include <iostream>
#include <fstream>
#include <string.h>

void permuation(std::ofstream &file, const char* str,
		const size_t size, const size_t counter = 0);


int main()
{
  char str[50]; // Buffer saving the entered string
  std::ofstream file; // The file object that saves the result
  file.open("outfile.txt");
  std::cout << "Please insert the 1-5 charactered word: " << std::endl;
  std::cin >> str;
  if (strlen(str) > 5 || strlen(str) == 0) // The questionnarie says the
                                           // input lenght is [0-5]
    {
      std::cout << "Invalid length!" << std::endl;
      file.close();
      return 0;
    }
  std::cout << "You have entered the word: " << str << std::endl;
  permuation(file, str, 4, 0); // The function is called
  file.close();
  std::cout << "The result is saved in file: outfile.txt" << std::endl;
  return 0;
}


// This is definition of the permuation function
void permuation(std::ofstream &file, const char* str,
		const size_t size, const size_t counter)
{
  static size_t per_ctr{}; // per_ctr will count the n-th
                           // permuation since the function is called
  if (size == 0)
    {
      file << "The input is empty!" << std::endl;
      return;
    }
  
  if (counter == size-1) // Here the permuation is set, therefore we
                         // write it in the file.
    {
      per_ctr++;
      file << per_ctr << "\t" << str << std::endl;
    }
  else
    {
      for (size_t i{counter}; i <= size-1; i++)
	{
	  char *nstr = new char [size];
	  for (size_t j{}; j < size; j++)
	    nstr[j] = str[j];
	  
	  char temp;
	  temp = nstr[counter];
	  nstr[counter] = nstr[i];
	  nstr[i] = temp;

	  permuation(file, nstr, size, counter + 1);
	  delete [] nstr;
	}
    }
}
