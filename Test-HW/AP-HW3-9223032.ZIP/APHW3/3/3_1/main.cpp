#include <iostream>
#include <string.h>
#include <utility>

using namespace std::rel_ops;


// This is beginning of the class definitions
class CMessage
{
 private:
  std::string* ptext;
 public:
  void show() const
  {
    std::cout << "Message is:" << *ptext << std::endl;
  }

  CMessage(const char* text = "No message")
    {
      ptext = new std::string{ text };
    }
  
  ~CMessage()
    {
      delete ptext;
    }

  // These are new operators added to class:
  // We will use this and some Templates defined below in orther define
  // The bool rels between CMessage and char*
  bool operator < (const CMessage& str) const
  {
    return ( this->ptext[0].size() < str.ptext[0].size() );
  }

  bool operator == (const CMessage& str) const
  {
    return ( this->ptext[0].size() == str.ptext[0].size() );
  }
};
// End of class definition

// All templates are defined here:
template <class T> bool operator == (const T& class1, const char* str)
{
  T class2_temp{str};
  return (class1 == class2_temp);
}
template <class T> bool operator < (const T& class1, const char* str)
{
  T class2_temp{str};
  return (class1 < class2_temp);
}

// These are new templates (like rel_ops)
template <class T> bool operator > (const T& class1, const char* str)
{
  return !(class1 == str) && !(class1 < str);
}
template <class T> bool operator != (const T& class1, const char* str)
{
  return !(class1 == str);
}
template <class T> bool operator <= (const T& class1, const char* str)
{
  return (class1 == str) || (class1 < str);
}
template <class T> bool operator >= (const T& class1, const char* str)
{
  return !(class1 < str);
}

int main()
{
  using namespace std::rel_ops;
  CMessage C1{"1231"};
  CMessage C2{"234"};
  std::cout << (C1<="1231231") << std::endl;
}
