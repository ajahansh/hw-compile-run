#include <iostream>
#include <string.h>
#include "ccomplex.h"
#include <stdio.h>

int main()
{
  CComplex a{2.5f, 3.0f};
  CComplex b{2.0f};
  std::cout << a.print() << std::endl;
  CComplex c{b};
  c.imag = -3.5f;
  a += b;
  c = (a + b) / (a + c);
  std::cout << "c= " << std::endl;
  std::cout << "mag= " << c.mag() << "\tang= " << c.ang() << std::endl;
}
