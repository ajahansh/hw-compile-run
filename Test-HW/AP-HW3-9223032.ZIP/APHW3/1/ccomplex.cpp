#include "ccomplex.h"

CComplex::CComplex(float i, float j)
{
  real = i;
  imag = j;
}

char* CComplex::print() const
{
  char temp[50];
  static char outstr[100];
  sprintf(outstr, "%f", real);
  sprintf(temp, "%f" , imag);
  strcat (outstr," +j");
  strcat(outstr, temp);
  return outstr;
}

CComplex::CComplex(const CComplex &CC)
{
  this->real = CC.real;
  this->imag = CC.imag;
}

void CComplex::operator += (const CComplex &CC2)
{
  this->real += CC2.real;
  this->imag += CC2.imag;
}

CComplex CComplex::operator + (const CComplex &CC2)
{
  CComplex temp{*this};
  temp += CC2;
  return (temp);
}

float CComplex::mag() const
{
  return sqrt(real*real + imag*imag);
}

float CComplex::ang() const
{
  return atan2(imag,real);
}

CComplex CComplex::operator / (const CComplex &CC2)
{
  CComplex temp{0.0f,0.0f};
  float denum{CC2.real * CC2.real + CC2.imag * CC2.imag};
  
  if (denum != 0.0f)
    {
      temp.real = (this->real*CC2.real - this->imag*CC2.imag) / denum;
      temp.imag = (this->real*CC2.imag + this->imag*CC2.real) / denum;
      return temp;
    }
  else
    std::cout << "Error: Divided by zero!" << std::endl;
  return temp;
}
