#include <iostream>
#include <stdio.h>
#include <string.h>
#include <math.h>

class CComplex
{
 public:
  CComplex(float i, float j=0);
  CComplex(const CComplex &CC); 
  char* print() const;
  float mag() const;
  float ang() const;
  void operator += (const CComplex &CC2);
  CComplex operator + (const CComplex &CC2);
  CComplex operator / (const CComplex &CC2);
  
  float real; //It's better to define these as private ones!
  float imag; //It's better to define this one as private..however we make it public too!
};
