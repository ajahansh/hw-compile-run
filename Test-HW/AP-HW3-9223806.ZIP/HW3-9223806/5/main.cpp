#include<iostream>
#include<string>
#include<fstream>

void allpermutation(std::string, std::string);
std::string total; // we define this inorder to save the permutations
                   // because the allpermutation function cannot have
                   // such a variable beacuse it has to define it
                   // every time it recurse into itself

int main()
{
  std::string input;
  std::cin >> input;
  allpermutation("", input);

  //making the output file
  std::ofstream Allpermutations("output.txt");
  Allpermutations << total;

  return 0;
}


  void allpermutation(std::string soFar, std::string rest)
{

  if(rest == "") 
    { 
      std::cout << soFar << "\n"; // this is one of the permutataions
      total = total + "\n" + soFar; // for output file
    }

  for(int i{0}; i < rest.length(); i++)
    { 
      std::string next{ soFar + rest[i] };
      std::string remaining {rest.substr(0, i) + rest.substr(i+1)};
     
      allpermutation(next, remaining);
    }
}


