#include<iostream>
#include<string>
#include<sstream>
#include"complex.h"

int main()
{

 CComplex a{2.5, 3}; // 2.5+3j
 CComplex b{2}; // 2+0j
 std::cout<<"a=";
 // Output real and imaginary parts
 std::cout << a.print() << std::endl; // 4.5 + 3j
 CComplex c{b}; // copy constructor
 c.imaginary = -3.5; // c.real should be accessible too ٨ a += b; // Implement +=
 c=(a+b)/(a+c);//Implement+and/ ١٠ cout<<"c=";
 // Output magnitude and angle
 std::cout << c.mag() << '<' << c.ang() << std::endl;


 return 0;
}
