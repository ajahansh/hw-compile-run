#include<iostream>
#include<sstream>
#include<string>
#include<cmath>
#include"complex.h"

CComplex::CComplex(float rel, float img): // cunstructor
  real{rel}, imaginary{img}
{
}

CComplex::CComplex(const CComplex& cmpnum): // copy cunstructor
  real{cmpnum.real}, imaginary{cmpnum.imaginary}
{
}

std::string CComplex::print()
{
  std::ostringstream outStr {}; 
  // we use ostringstream because our string is multitype
  outStr << real << "+" << imaginary << "j";
  std::string compnum;
  return compnum = outStr.str();
}


CComplex CComplex::operator+(const CComplex& cmpnum) const
{
    CComplex result(real + cmpnum.real, imaginary + cmpnum.imaginary);
    return result;
}

CComplex CComplex::operator+=(const CComplex& cmpnum)
 // not const!! it changes the ""this->obj"" amount
{
  this->real = this->real + cmpnum.real;
  this->imaginary = this-> imaginary + cmpnum.imaginary;
}

CComplex CComplex::operator/(const CComplex& cmpnum) const
{
  float a, b, c;
  a = (real * cmpnum.real) + (imaginary * cmpnum.imaginary);
  b= (-1 * real * cmpnum.imaginary) + (imaginary * cmpnum.real);
  c =  (cmpnum.real * cmpnum.real) + (cmpnum.imaginary * cmpnum.imaginary);
 CComplex dev{ a / c, b /c };
 return dev;
  }


float CComplex::mag()
{
  float magnitude{ sqrtf ((real * real) + (imaginary * imaginary))};
  // sqerf gets the root of float numbers
  return magnitude;
}


float CComplex::ang()
{
  float angel{ atanf ( imaginary / real ) };
 //atanf is arctan for float numbers
  return (angel * 180 / 3.1415) ;
}
