class CComplex
{

 public:
  
  float real, imaginary; // public variables so that we
                         // have access from main

  CComplex(float rel = 0, float img = 0);   // cunstructor
  CComplex(const CComplex& cmpnum); // copy custructor

  std::string print();
  float mag();
  float ang();
  CComplex operator+(const CComplex& cmpnum) const;
  CComplex operator+=(const CComplex& cmpnum);
  CComplex operator/(const CComplex& cmpnum) const;
 
private:
  // we don't have anything here
};
