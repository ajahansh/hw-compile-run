#include <iostream>
#include <string>
#include <vector>
#include <fstream>

std::vector<std::string> permutation(std::string);

int main()
{
  std::ofstream out{"output.txt"};
  std::string input;
  while(input.length() < 1 || input.length() > 5) //checking input length
    {
     std::cout << "enter the string that contains between 1 and 5 letters"
               << std::endl;
     std::cin >> input;
    }

  std::cout << "-----------" << std::endl;
  
  std::vector<std::string> perm{permutation(input)};
  // using the recursive function
  
   for(size_t k{}; k < perm.size(); k++)
     out << perm[k] << std::endl;
  
  return 0;
}

std::vector<std::string> permutation(std::string unprocessed)
{
  size_t size{unprocessed.length()};
  std::vector<std::string> temp;
  
  if(unprocessed.length() == 1)
   {
     temp.push_back(unprocessed);
     return temp;
   }

  temp =permutation(unprocessed.substr(1, size - 1));
  //here is recursion temp is the previous permutation
  
  std::vector<std::string> temp1{temp};
  
    for(size_t i{}; i < temp.size(); i++)
      temp1[i] = unprocessed[0] + temp1[i];
      //now temp1 contains permutes starting with unprocessed[0]
      
     for(size_t k{}; k < temp.size(); k++)
       for(size_t j{1}; j < size; j++)
	{
	  std::swap(temp1[k][0],temp1[k][j]);
          temp1.push_back(temp1[k]); // add a new permute to result
	  std::swap(temp1[k][0],temp1[k][j]);//reswap to avoid change 
        }
       
  return temp1;
}

