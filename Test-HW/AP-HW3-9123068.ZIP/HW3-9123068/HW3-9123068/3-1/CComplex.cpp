#include "CComplex.h"
#include <iostream>
#include <string>
#include <cmath>
#include <sstream>
CComplex::CComplex(float r, float i)
{
  real = r;
  imag = i;
}

CComplex::CComplex(const CComplex& obj)
{
  std::cout << "copy constructor called" << std::endl;
}

float CComplex::mag() const
{
  return sqrt(real * real + imag * imag); //magnitude
}

float CComplex::ang() const
{
  return atan(imag / real); //angle
}

std::string CComplex::print() const
{
 std::stringstream convert; // stringstream used for the conversion
 std::stringstream Convert;
 convert << real;
 std::string re{convert.str()};
 Convert << imag;
 std::string im{Convert.str()};
 
 return re + " + " + im + 'j'; 
}

CComplex CComplex::operator+(const CComplex& operand2) const
    {
        return CComplex(real + operand2.real, imag +operand2.imag);
    }

CComplex CComplex::operator-(const CComplex& operand2) const
    {
        return CComplex(real - operand2.real, imag - operand2.imag);
    }

CComplex CComplex::operator/(const CComplex& operand2) const
    {
      float magni{this->mag() / operand2.mag()};
      float angle{this->ang() - operand2.ang()};
      return CComplex(magni * cos(angle), magni * sin(angle));
     }

CComplex CComplex::operator*(const CComplex& operand2) const
    {
      float magni{this->mag() * operand2.mag()};
      float angle{this->ang() + operand2.ang()};
      return CComplex(magni * cos(angle), magni * sin(angle));
    }

CComplex& CComplex::operator+=(const CComplex& operand2)
{
  real += operand2.real;
  imag += operand2.imag;
  return *this;
}
