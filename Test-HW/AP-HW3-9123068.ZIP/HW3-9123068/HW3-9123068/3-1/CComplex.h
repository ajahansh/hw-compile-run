#include <string>
class CComplex
{
public:
  
  CComplex(float r = 0.0, float i = 0.0);
  CComplex(const CComplex&); //copy constructor
  CComplex operator+(const CComplex&) const;//addition
  CComplex operator-(const CComplex&) const;//subtraction
  CComplex operator*(const CComplex&) const;//multiplication
  CComplex operator/(const CComplex&) const;//division
  CComplex& operator+=(const CComplex&);//+= implementation
  std::string print() const;
  float mag() const;
  float ang() const; 
  float real, imag;
};
