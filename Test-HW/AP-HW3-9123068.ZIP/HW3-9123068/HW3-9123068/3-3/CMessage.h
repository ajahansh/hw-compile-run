#include <iostream>
#include <string>

class CMessage
{
private:
const char* ptext; // Pointer to object text string

public:
// Function to display a message

void show() const
{
 std::cout << "Message is:" << *ptext << std::endl;
}

// Constructor
CMessage(const char* text = "No message")
{
 ptext = text; // Allocate space for text
}

 bool operator<(const char* obj)
 {
     return *ptext < obj[0];
 }

 bool operator==(const char* obj)
 {
     return *ptext == obj[0];
 }
};
