#include "CMessage.h"
#include <iostream>

template<class T1, class T2>
bool operator>(T1 t1, T2 t2);

template<class T3, class T4>
 bool operator!=(T3 t3, T4 t4);

template<class T5, class T6>
 bool operator>=(T5 t5, T6 t6);

int main()
{
  const char* c{"M"};
  CMessage a{};
  bool b{c > a};
  std::cout << c << " > a" << " = " << b << std::endl;
  b = c != a;
  std::cout << c << " != a" << " = " << b << std::endl;
  b = c >= a;
  std::cout << c << " >= a" << " = " << b << std::endl;
  return 0;
}

template<typename T1, typename T2>  
 bool operator>(T1 t1, T2 t2)
 {
  return t2 < t1;
 }

template<typename T5, typename T6>  
 bool operator>=(T5 t5, T6 t6)
 {
   return (t5 > t6) || (t6 == t5);
 }

template<typename T3, typename T4>
 bool operator!=(T3 t3, T4 t4)
 {
  return !(t4 == t3);
 }
