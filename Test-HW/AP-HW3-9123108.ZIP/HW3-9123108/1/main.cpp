#include <iostream>
#include "complex.h"
#include <math.h>

int main()
{
	ccomplex a{2.5, 3}; // 2.5+3j
	ccomplex b{2}; // 2+0j
	std::cout << "a = ";
    // Output real and imaginary parts
	std::cout << a.print() << std::endl; // 4.5 + 3j
	ccomplex c{b}; // copy constructor
	c.imag = -3.5; // c.real should be accessible too
	a += b; // Implement +=
	c = (a + b) / (a + c); // Implement + and /
	std::cout << "c = ";
    // Output magnitude and angle
	std::cout << c.mag() << '<' << c.ang() << std::endl;
	return 0;
}
