class ccomplex
{
public:
	// basic functions
	ccomplex(const float, const float);
	ccomplex(const float);
	ccomplex(const ccomplex&);
	ccomplex(const ccomplex&&);
	ccomplex();
	~ccomplex();
	ccomplex& operator=(const ccomplex&);
	ccomplex operator+(const ccomplex&) const;
	ccomplex& operator+=(const ccomplex&);
	ccomplex operator/(const ccomplex&) const;
  
	// user functions 
	float mag(void) const;
	float ang(void) const;
	const char* print(void) const;
	// variables
	float imag{},real{};
private:
};
