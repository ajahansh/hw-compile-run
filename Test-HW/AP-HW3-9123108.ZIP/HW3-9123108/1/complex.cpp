#include <iostream>
#include <cmath>
#include "complex.h"
#include <sstream>
#include <string>

ccomplex::ccomplex(const float real, const float imag)
{
	this->real = real;
	this->imag = imag;
	std::cout << "Normal Constructor" << std::endl;
}

ccomplex::ccomplex(const float real)
{
	this->real = real;
	this->imag = 0;
	std::cout << "one arg Normal Constructor" << std::endl;
}

ccomplex::ccomplex(const ccomplex& complex)
{
	this->real = complex.real;
	this->imag = complex.imag;
	std::cout << "Copy Constructor" << std::endl;
}

ccomplex::ccomplex(const ccomplex&& complex)
{
	this->real = complex.real;
	this->imag = complex.imag;
	std::cout << "Move Constructor" << std::endl;
}

ccomplex::ccomplex(): ccomplex(0, 0)
{
	std::cout << "Default Constructor" << std::endl;
}

ccomplex::~ccomplex()
{
	std::cout << "Destructor" << std::endl;
}

ccomplex& ccomplex::operator=(const ccomplex& complex)
{
	this->real = complex.real;
	this->imag = complex.imag;
	std::cout << "Operator =" << std::endl;
	return *this;
}

ccomplex ccomplex::operator+(const ccomplex& complex) const
{
	std::cout << "Operator +" << std::endl;
	return ccomplex {this->real + complex.real, this->imag + complex.imag};
}

ccomplex& ccomplex::operator+=(const ccomplex& complex)
{
	std::cout << "Operator +=" << std::endl;
	this->imag  =  this->imag + complex.imag;
	this->real = this->real + complex.real;
	return (*this);
}

ccomplex ccomplex::operator/(const ccomplex& complex) const
{
	float mag1, mag2;
	float ang1, ang2;
	
	mag1 = this->mag();
	mag2 = complex.mag();
	ang1 = this->ang();
	ang2 = complex.ang();
	
	std::cout << "Operator /" << std::endl;

	return ccomplex {(mag1 / mag2) * cosf(ang1 - ang2),
			         (mag1 / mag2) * sinf(ang1 - ang2)};
}

float ccomplex::mag() const
{
	return sqrtf(imag * imag + real * real);
}

float ccomplex::ang() const
{
	return atanf(imag / real);
}

const char* ccomplex::print() const
{
	std::stringstream s;
	s  << this->real << " + " << this->imag << "j";
	std::string out_string {s.str()};
	return out_string.c_str();
}
