#include <algorithm>
#include <iostream>
#include <fstream>
#include <string>

void PrintPermutation(std::string& str);
bool RecursivePermutation(std::string& str, std::ofstream& output);
	
int main()
{	
	std::string a{"9311"};
	PrintPermutation(a);
	return 0;
}

void PrintPermutation(std::string& str)
{
	std::ofstream output {"output.txt"};
	sort(str.begin(), str.end());
	RecursivePermutation(str, output);
	output.close();
}

bool RecursivePermutation(std::string& str, std::ofstream& output)
{
	output << str << std::endl;
	if(!next_permutation(str.begin(), str.end()))
		return 0;
	RecursivePermutation(str, output);
	return 0;
}
