#include<iostream>
//#include"message.h"

template<typename T>
bool operator>(const T&, const char*);
template<typename T>
bool operator>=(const T&, const char*);
template<typename T>
bool operator!=(const T&, const char*);

int main()
{
	return 0;
}

template<typename T>
bool operator>(const T& classtype, const char* chstr)
{
	return !((classtype < chstr)||(classtype == chstr)); //should be defined
}

template<typename T>
bool operator>=(const T& classtype, const char* chstr)
{
	return !(classtype < chstr); //should be defined
}

template<typename T>
bool operator!=(const T& classtype, const char* chstr)
{
	return !(classtype == chstr); //should be defined
}
